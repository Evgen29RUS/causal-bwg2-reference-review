# CAUSAL 2.0 — Phase 3Z / BW-G2 Synthetic Golden Vector Specification v0.1

**Artifact:** `BW-G2 Synthetic Golden Vector Specification`  
**Status:** `DESIGN PREPARED / AWAITING PO ACCEPTANCE`  
**Authority:** Phase 3Z `AUTHORIZED / GO`, explicitly `DESIGN-ONLY / REVIEW`; 2026-10-30.  
**Baseline:** Phase 3Y `CLOSED / ACCEPTED` by PO.  
**Material produced:** requirements specification, review matrices, source pins and SHA-256 **only**.  
**Not produced:** machine-readable corpus, fixtures, actual canonical byte values, test signatures, keys, verifier, runnable tests, independent cross-language implementations, trust providers, real source I/O.

> **NON-NEGOTIABLE TRUST BOUNDARY.** `BW-G2 = DESIGN PROPOSED / NOT FROZEN`; `3Q-CR-01 = DESIGN RESOLUTION PROPOSED`; `3M-RV-18…24 = P0 / OPEN` (7/7). Composite Evidence Schema, Trust Anchor Contract v0.1 and Key Authorization Contract v0.1 remain `REVIEW ACCEPTED / NOT FROZEN`. ResearchState / Experiment Selection / Research Orchestrator v1.0 remain `FROZEN / UNCHANGED`. No changes to `C:\CAUSAL 2.0`, production code, Oracle, PPO, Journal, BlobStore or autonomous execution. `external_provenance=NOT_VERIFIED`, `trusted_admission=DENIED`, `trusted_implementation=NO-GO`, `autonomous_execution=NO-GO`. A design review is **not** authorization to create or run vectors.

## 0. Executive decision for PO

**3Z-D-01 — Specify, do not instantiate.** Define the exact future *record requirements*, expected byte-derivation semantics, rejection-stage rules, cross-language independence and complete coverage inventory. Do **not** populate any raw JSON, hex, digest, public key or signature fixtures now. A list of proposed test case IDs is not a golden corpus.

**3Z-D-02 — Separate outcomes.** Distinguish local `PARSE/SCHEMA/CANONICAL/FRAME/DIGEST/SIGNATURE/GRAPH` verdicts from external `PROVENANCE`, from `trusted_admission`, and from execution. A locally valid synthetic vector always ends `UNVERIFIED / DENIED`; a malformed vector must fail at its designated stage **even if** a global denied gate is present.

**3Z-D-03 — Require independent oracle.** Expected bytes must be independently curated, independently reviewed and compared against at least two independent parser/canonicalizer implementations in different languages. Two wrappers of the same library are not independent. Disagreements block conformance and cannot be settled by an implementation regenerating its own expectation.

**3Z-D-04 — Boundary on carriers.** Quartet R1V2/R2V2/R3V2/R5V2 can be specified for a *future synthetic vector corpus*; all 13 carrier families, real witness proofs and provider-specific attestations remain `P0-BLOCKED`. Any carrier negative vector describes a future expected failure, not a verified cryptographic transcript.

**3Z-D-05 — Future execution gate.** Do not select operational languages, generate synthetic key pairs, create fixture JSON/hex, run validators, or freeze a test profile under Phase 3Z. Future corpus generation, differential tests and any narrower immutable test-profile pin require a **new explicit PO GO**, scoped to offline synthetic-only work.

## 1. Source baseline / identity and precedence

Precedence for interpretation: latest explicit PO scope → frozen scientific v1.0 contracts → PO-accepted but not frozen design documents → current Phase 3Z **proposal**. SHA-256 pins below prove byte identity of the local reference documents, **not** their external authenticity or authority.

| Phase | Local controlling document | SHA-256 (document) |
|---|---|---|
| 3M | `CAUSAL_2_0_PHASE_3M_COMPOSITE_EVIDENCE_SCHEMA_CROSS_CONTRACT_FREEZE_REVIEW_v0.1.md` | `1c6f7568e5b48954b4b00faab7358b59d588482a8f3d973c3fee5f7402b53afa` |
| 3S | `CAUSAL_2_0_PHASE_3S_BOOTSTRAP_WIRE_SCHEMA_ACYCLIC_REFERENCE_REVIEW_v0.1.md` | `8901181c49c57e79467dd0c468e70441291102e2eeffc5882651298c4803048a` |
| 3T | `CAUSAL_2_0_PHASE_3T_BOOTSTRAP_CANDIDATE_SCHEMA_CONFORMANCE_PLAN_v0.1.md` | `4ab79b5bc4c590d97daf0d9d016868eef8125047e6b527dff87090d5203f6fa0` |
| 3U | `CAUSAL_2_0_PHASE_3U_CANDIDATE_MACHINE_SCHEMA_SPECIFICATION_REVIEW_v0.1.md` | `11081301d635e2ff6cb0eabed8b6d7b1f9a43db73cf80cb5103c889ccf82aeb8` |
| 3V | `CAUSAL_2_0_PHASE_3V_SCHEMA_CONFLICT_ADJUDICATION_EXACT_CARRIER_REQUIREMENTS_REVIEW_v0.1.md` | `d6bbc763c4c5a6291f5ef8c797df07c08d33090a0a7ebac688a202bd3a87f124` |
| 3W | `CAUSAL_2_0_PHASE_3W_TYPED_REFERENCE_REVISION_EXTERNAL_CARRIER_PROFILE_REVIEW_v0.1.md` | `7fb4f71de909e886ac7675dce9fcd531edd199df61a6b7e2a00b5b43dfe7db9c` |
| 3X | `CAUSAL_2_0_PHASE_3X_BWG2_BYTE_PROFILE_DETACHED_CARRIER_PROOF_FORMAT_DECISION_REVIEW_v0.1.md` | `78f331c689df4f4ae47a8e1d1c0657c1d9abdd25465eb2c1e53ec62c44244797` |
| 3Y | `CAUSAL_2_0_PHASE_3Y_BWG2_CROSS_LANGUAGE_VECTOR_CARRIER_CLOSURE_READINESS_REVIEW_v0.1.md` | `079e4996f0a7e50a1002e4e5d2c5717e6d3a611298d664020cc7866aad6d7604` |

No silent amendment of 3X/3Y decisions. Exact current source version and PO acceptance must be written into a future corpus manifest. A mismatched pin is `REFERENCE_DRIFT / BLOCKED`, never an invitation to reinterpret old bytes. This document does not modify `AnchorPayloadV1` or the Phase 3H in-memory synthetic verifier.

## 2. Quartet scope, fields and reference types (candidate; not frozen)

| Subject | Exact `contract` literal | Exact `domain` literal | Required top-level field count | Status |
|---|---|---|---:|---|
| R1V2 | `RootApprovalIntentV2` | `CAUSAL-KAA-ROOT-INTENT-v2` | 14 | Candidate only |
| R2V2 | `GenesisApprovalV2` | `CAUSAL-KAA-GENESIS-APPROVAL-v2` | 13 | Candidate only |
| R3V2 | `InitialFloorCommitmentV2` | `CAUSAL-TRUST-INITIAL-FLOOR-v2` | 12 | Candidate only |
| R5V2 | `BootstrapActivationCandidateV2` | `CAUSAL-KAA-BOOTSTRAP-ACTIVATION-v2` | 13 | Candidate only |

**Field-contract source:** use exact exhaustive 3U §4 key lists, replacing **only** `contract` literals with their V2 names and the two explicitly revised keys from 3W/3X:

- R1V2: `previous_root_approval_intent_ref` replaces `previous_root_approval_intent_digest`.
- R5V2: `previous_approved_activation_ref` replaces `previous_approved_activation_digest`.
- R2V2/R3V2: no other key-list changes; their contract literal and signing domain are V2.

Each of the two `*_ref` fields is a closed tagged union. `GENESIS`: exactly `kind="GENESIS"`, `genesis_rule_id` (authorized independently). `PRIOR`: exactly `kind="PRIOR"`, `target_contract`, `target_body_sha256`, `target_version` with exact target contract and prior accepted lineage. An absent predecessor is not genesis. R1 `PRIOR` targets R1V2 only; R5 `PRIOR` targets **approved** earlier R5V2 only. `GENESIS` in a predecessor is not R2's GenesisApproval subject. All remaining `*_digest` fields are lowercase 64-hex but must additionally bind to specified target contract, domain, rank and lineage, not just equal hex.

`NS4=(project_id,journal_id,source_epoch,policy_id)` is four *flat* mandatory keys in each body; expected NS4 comes from an out-of-band, independently authorized context. R2 `initial_source_state_commitment` is exactly one `EXACT_SOURCE_GENESIS` (explicit source state digest) or `AUTHORIZED_ABSENT_SOURCE` (explicit absent-source rule); R3 `initial_predecessor` uses the explicit initial genesis ref. No future receipt or approval digest is embedded in an earlier signed body. No V1→V2 byte, alias or authority migration is implied.

The corpus may record a *synthetic expected scope* for testing equality, but its value is not an independently authorized source scope.


### 2.1. Exhaustive proposed top-level key inventory (source-derived; BW-G2 candidates)

For a standalone review, the following exact field names are mandatory. Every listed row is a **candidate signed-body requirement**, not a machine validator. `contract` uses the V2 literal of §2. Nested tagged unions have the closed shape described above.

| Subject | Exact required top-level fields (comma-separated in schema-definition order; canonical order is JCS, **not** this table) |
|---|---|
| R1V2 (14) | `contract`, `project_id`, `journal_id`, `source_epoch`, `policy_id`, `intent_version`, `root_policy_version`, `independently_pinned_approval_authority_policy_digest`, `root_key_set_commitment`, `scope_set_commitment`, `kaa_quorum_policy_commitment`, `witness_and_custody_policy_commitment`, `allowed_signing_domains_commitment`, `previous_root_approval_intent_ref` |
| R2V2 (13) | `contract`, `project_id`, `journal_id`, `source_epoch`, `policy_id`, `genesis_id`, `genesis_approval_version`, `root_approval_intent_digest`, `independently_pinned_approval_authority_policy_digest`, `source_genesis_rule_id`, `initial_source_state_commitment`, `initial_trust_state_digest`, `genesis_boundary_commitment` |
| R3V2 (12) | `contract`, `project_id`, `journal_id`, `source_epoch`, `policy_id`, `initial_floor_version`, `root_approval_intent_digest`, `genesis_approval_digest`, `initial_trust_state_digest`, `genesis_boundary_commitment`, `custody_policy_id`, `initial_predecessor` |
| R5V2 (13) | `contract`, `project_id`, `journal_id`, `source_epoch`, `policy_id`, `bootstrap_version`, `root_approval_intent_digest`, `genesis_approval_digest`, `initial_floor_commitment_digest`, `approved_scope_set_commitment`, `preceding_approved_policy_commitment`, `previous_approved_activation_ref`, `activation_state` |

These lists preserve 3U §4 except the two specific 3W/3X renamed keys and V2 `contract` discriminator. No extra algorithm ID, carrier signature, public key, receipt, `body_sha256` self-reference, external root or optional field may be inserted into these signed bodies without a separately versioned PO change record. Plain digest fields must have appropriate external expected contract/domain binding.

## 3. Future exact byte derivation and rejection order

### 3.1. Proposed restricted grammar (before JCS)

- Input: one UTF-8 JSON object, **no BOM**; closed key sets; reject duplicate keys before materialization at every level; no `null`, bool, float, arrays, unknown fields, unsupported escape aliases, unpaired surrogate or non-ASCII value in this narrowed quartet profile. Only closed tagged nested objects are permitted. External carrier schemas may differ and do not inherit these restrictions.
- Integers: safe JSON range up to `9007199254740991` with positive/zero rules per 3U type; lexically reject `-0`, exponent, fraction and leading zeros before host-language coercion. `true` is not integer `1`.
- `NS_ID` and `LOCAL_ID`: candidate ASCII `^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$`, case-sensitive; no Unicode normalization, case folding, path/URL coercion or inferred defaults.
- Canonical signed-body bytes: RFC 8785 JCS of the **strict parsed, valid** signed body. Field-name sorting is UTF-16-code-unit based (the permitted keys are ASCII). No BOM, insignificant whitespace or trailing newline. Legal whitespace/key-order differences in unsigned transport are *not automatically* a signed-byte failure; compare recomputed canonical `P`. If a carrier asserts exact canonical bytes, those asserted bytes must match `P` exactly.

### 3.2. Candidate frame and signature inputs (exact operation ordering)

```text
P := UTF8(RFC8785_JCS(validated_signed_body))
L := number_of_octets(P)
D := exact allowlisted ASCII subject signing domain
frame := ASCII(D) || 0x00 || uint64_be(L) || P
body_sha256 := lowercase_hex(SHA256(frame))
future_synthetic_signature := pure_Ed25519.Sign(ephemeral_test_sk, frame)
```

No user- or document-provided byte string is generated by this specification. `uint64_be(L)` is **exactly eight octets, big-endian**, not an authorization for unlimited input length. `body_sha256` is over the **full frame**, not just `P`, wrapper, source blob or previous anchor. Pure Ed25519 signs the full frame (not its SHA-256 digest); Ed25519ph/ctx and algorithm negotiation are rejected. Future synthetic public key and signature are respectively 32 and 64 octets. The test key is ephemeral and non-authoritative. Actual resource limits remain blocked by RV-24.

### 3.3. Ordered local verdicts in future conformance

| Stage | Check | On failure (candidate classification) |
|---|---|---|
| 0 | Corpus record identity, source pins, reviewer-approved oracle, test profile | `VECTOR_INCOMPLETE` or `VECTOR_ORACLE_NOT_INDEPENDENT` |
| 1 | UTF-8, BOM, JSON lexeme, duplicate keys, object shape | `CANONICAL_BYTES_INVALID` |
| 2 | Exact closed V2 schema, version, NS4, tagged union grammar | `SCHEMA_UNSUPPORTED` / `TYPED_REFERENCE_MISMATCH` |
| 3 | RFC8785 `P`, asserted canonical bytes and length | `CANONICAL_BYTES_INVALID` / `CONFORMANCE_BLOCKED` |
| 4 | Exact D/NUL/uint64-be byte frame | `SIGNING_FRAME_MISMATCH` |
| 5 | SHA-256 of full frame | `BODY_DIGEST_MISMATCH` |
| 6 | Pure Ed25519 verify against explicitly supplied *synthetic* key | `SIGNATURE_INVALID` / `SIGNATURE_PROFILE_UNSUPPORTED` |
| 7 | Typed references, predecessor rank, namespace/lineage | `TYPED_REFERENCE_MISMATCH`, `GENESIS_NOT_AUTHORIZED` or specific code |
| 8 | External issuer, custody, witness, source/time/floor profiles | `PROOF_PROFILE_UNSUPPORTED`, other explicit P0 diagnosis |
| 9 | Admission and downstream authorization | Always `UNVERIFIED / trusted_admission=DENIED`, no RS→ES→ORC |

If a previous stage fails, downstream positive predicates must be `NOT_EVALUATED` or `NOT_APPLICABLE` by explicit tagged result branch; never fabricate successful digest/signature values. A global `DENIED` result does **not** make a malformed vector a PASS at an incorrect stage. Error names are proposed review-level expectations, not errors already emitted by deployed code.

## 4. Required structure of a *future* synthetic golden corpus (NOT CREATED)

### 4.1. Manifest requirements (closed candidate inventory, not JSON schema)

Every future immutable manifest SHALL specify: `corpus_id`, `corpus_revision`, `candidate_protocol_id=BW-G2`, `source_document_ids_and_sha256` (including precise PO baseline), `schema_profile_digest`, `vector_inventory_digest`, `implementation_independence_policy`, `synthetic_only=true`, `expected_trusted_admission=DENIED`, `generator_provenance`, `reviewer_signoff_state`, `supersedes_corpus_digest` with explicit first-corpus `GENESIS` alternative, and per-group expected/actual case counts. It must also bind `oracle_origin`, `oracle_reviewer_identity_ref`, `oracle_review_decision`, `entry_ordering_rule`, `exact_case_ids`, `byte_record_encoding`, `negative_not_applicable_policy` and corpus identity to one immutable review record. These latter fields are **additional requirements proposed by Phase 3Z**, not silently adopted earlier names.

**Future freeze of a synthetic test profile** (if PO authorizes) must pin immutable manifest bytes, its full cryptographic digest, entry digests, all toolchain dependencies and a clear `SYNTHETIC / NOT A TRUST SCHEMA FREEZE` label. No manifest, test profile or fixture is created now.

### 4.2. Future per-vector record obligations

| Family | Required proposed fields | Precision rule |
|---|---|---|
| Identity | `vector_id`, `category`, `origin_ref`, `subject_contract`, `subject_domain`, `revision`, `expected_NS4` | Exact case ID, one subject generation; independent expected context is **synthetic** only |
| Raw | `input_json_utf8_hex`, `input_byte_count`, `raw_transport_interpretation` | Exact octets and lexemes; no inferred UTF-16 or normalized strings |
| Canonical | `canonical_payload_utf8_hex`, `canonical_payload_length_decimal`, `canonical_expected_state` | Hex must reflect exact `P`, not an implementation recomputation |
| Frame | `domain_ascii_hex`, `separator_hex`, `uint64_be_length_hex`, `signing_frame_hex`, `frame_expected_state` | `00`, exact 8-byte length, exact concatenation |
| Digest | `body_sha256`, `hash_input_kind=FRAME`, `digest_expected_state` | Lowercase SHA-256 of full frame |
| Synthetic signature | `test_public_key_hex`, `test_signature_hex`, `test_algorithm=pure-Ed25519`, `test_key_provenance=EPHEMERAL_SYNTHETIC`, `signature_expected_state` | 32/64-octet shape; no key auth implication |
| Graph | `typed_ref_branch`, `expected_target_contract`, `expected_target_domain`, `expected_target_version`, `edge_identity_digests`, `graph_expected_state` | Typed and out-of-band expected bindings, no self-trust |
| Verdict | `expected_parse`, `expected_schema`, `expected_canonical`, `expected_frame`, `expected_digest`, `expected_signature`, `expected_linkage`, `expected_external_provenance=NOT_VERIFIED`, `expected_trusted_admission=DENIED` | Stage-wise checks; `NOT_EVALUATED` explicitly when earlier stage rejects |
| Diagnostic | `expected_issue_codes`, `reject_stage`, `accepted_transport_noncanonical`, `corpus_profile_digest` | No silent fallback; success of denied gate alone insufficient |
| Independence | `implementation_ids`, `language_versions`, `cryptography_backend_versions`, `reference_vector_origin`, `agreement_matrix_ref`, `review_decision_ref` | Must disclose shared dependencies and actual separate reviewer |

**Negative branch rule:** when strict parsing fails, expected canonical/frame/digest/signature fields are *not fabricated*. Their presence/absence must use a future **closed tagged `NOT_APPLICABLE` branch with reason and reject_stage**, not permissive `null`, `""` or omitted fields. This document specifies that behavior but does not invent a final branch wire IDL. A verifier may not compare a nonexistent signature and then call it a passed cryptographic check. For valid local subjects, expected exact bytes and crypto results are mandatory **when independently generated** in an authorized later phase.

**3Z-OPEN-01 — byte length versus character count:** the currently permitted quartet produces ASCII-only canonical `P`, so a buggy *character-count* implementation can accidentally equal the correct byte count on every valid specimen. This corpus can detect intentionally mismatched framed lengths, but cannot honestly claim to distinguish those two length-count algorithms solely using *valid* BW-G2 subjects. Such an algorithm-level defect requires independent code review or a separately authorized non-ASCII extension test profile; inserting Unicode into valid BW-G2 would contradict the candidate grammar. Retain the original Phase 3X/3Y requirement as a blocked differential-test coverage question, not a verified future PASS.

**Corpus size/count integrity:** exactly one `vector_id` per unique case, every ID mapped to one primary V-group; cross-coverage is additional metadata, never counted twice. Fail if a future case is duplicated under another label to meet the 102 floor, if a negative case lacks its decisive reject stage, or if a supposedly valid case omits independently curated expected bytes.

## 5. Proposed exact inventory: 102 *future* vector requirements, 0 instantiated

**Key:** `P` = locally valid synthetic subject/behavior to compare exact bytes; `N` = deliberately invalid input, frame, graph or external claim. Both end `UNVERIFIED / DENIED`. `P` does **not** mean externally authorized or that the test passed; all case descriptions are **specification-only**. A blocked external carrier case tests eventual diagnostic classification, not a completed proof. The expected `reject_stage` follows §3.3. Actual expected hex/digests/signatures are intentionally absent.

### 5.A — V-A: Closed schema, V2 objects and exact types (14 planned requirements)

| Future vector ID | Mode | Single required stimulus / contrast | Expected local evidence |
|---|---|---|---|
| `3Z-V-A-01` | P | R1V2 with all 14 exact required keys and explicit GENESIS predecessor | `SCHEMA_OK`; admission DENIED |
| `3Z-V-A-02` | P | R1V2 with 14 keys and approved-shape PRIOR target | `SCHEMA_OK`; admission DENIED |
| `3Z-V-A-03` | P | R2V2 with EXACT_SOURCE_GENESIS branch and 13 keys | `SCHEMA_OK`; admission DENIED |
| `3Z-V-A-04` | P | R2V2 with AUTHORIZED_ABSENT_SOURCE branch and 13 keys | `SCHEMA_OK`; admission DENIED |
| `3Z-V-A-05` | P | R3V2 12-key body and explicit initial predecessor | `SCHEMA_OK`; admission DENIED |
| `3Z-V-A-06` | P | R5V2 13-key CANDIDATE with GENESIS predecessor | `SCHEMA_OK`; admission DENIED |
| `3Z-V-A-07` | P | R5V2 13-key CANDIDATE with PRIOR predecessor | `SCHEMA_OK`; admission DENIED |
| `3Z-V-A-08` | N | R1V2 missing one mandatory root commitment | `SCHEMA_REJECT`; admission DENIED |
| `3Z-V-A-09` | N | R2V2 contains extra field named bootstrap_digest | `SCHEMA_REJECT`; admission DENIED |
| `3Z-V-A-10` | N | R3V2 includes embedded R4 receipt digest | `SCHEMA_REJECT`; admission DENIED |
| `3Z-V-A-11` | N | R5V2 carries activation_state other than CANDIDATE | `SCHEMA_REJECT`; admission DENIED |
| `3Z-V-A-12` | N | NS4 mismatches independent synthetic expected_ns | `SCHEMA_REJECT`; admission DENIED |
| `3Z-V-A-13` | N | R1V2 predecessor is string digest instead of tagged ref | `SCHEMA_REJECT`; admission DENIED |
| `3Z-V-A-14` | N | R0/R4/R6/R7/R8 partial carrier presented as closed BW-G2 subject | `PROOF_BLOCKED`; admission DENIED |

### 5.B — V-B: Strict UTF-8/JSON/JCS canonicalization (16 planned requirements)

| Future vector ID | Mode | Single required stimulus / contrast | Expected local evidence |
|---|---|---|---|
| `3Z-V-B-01` | P | Same R1 values with permuted transport field order; identical P | `CANONICAL_MATCH`; admission DENIED |
| `3Z-V-B-02` | P | Same R2 values with permitted transport whitespace; identical P | `CANONICAL_MATCH`; admission DENIED |
| `3Z-V-B-03` | P | R3 canonical key sort per UTF-16 on ASCII field names | `CANONICAL_MATCH`; admission DENIED |
| `3Z-V-B-04` | P | R5 nested tagged union with canonical field ordering | `CANONICAL_MATCH`; admission DENIED |
| `3Z-V-B-05` | N | UTF-8 BOM on signed-body transport | `PARSE_REJECT`; admission DENIED |
| `3Z-V-B-06` | N | Ill-formed UTF-8 byte sequence | `PARSE_REJECT`; admission DENIED |
| `3Z-V-B-07` | N | Duplicate top-level contract property | `PARSE_REJECT`; admission DENIED |
| `3Z-V-B-08` | N | Duplicate nested PRIOR target_version property | `PARSE_REJECT`; admission DENIED |
| `3Z-V-B-09` | N | Negative zero -0 numeric lexeme | `PARSE_REJECT`; admission DENIED |
| `3Z-V-B-10` | N | Integral value encoded 1.0 | `PARSE_REJECT`; admission DENIED |
| `3Z-V-B-11` | N | Integral value encoded 1e0 | `PARSE_REJECT`; admission DENIED |
| `3Z-V-B-12` | N | Leading-zero 01 JSON number | `PARSE_REJECT`; admission DENIED |
| `3Z-V-B-13` | N | Integer beyond 9007199254740991 in safe-bound slot | `SCHEMA_REJECT`; admission DENIED |
| `3Z-V-B-14` | N | Unicode/escaped alias for ASCII-only identifier | `SCHEMA_REJECT`; admission DENIED |
| `3Z-V-B-15` | N | Null or boolean in required integer slot | `SCHEMA_REJECT`; admission DENIED |
| `3Z-V-B-16` | N | Invalid unpaired Unicode surrogate / noncanonical escape | `PARSE_REJECT`; admission DENIED |

### 5.C — V-C: Domains, signing frame, digest and synthetic cryptography (14 planned requirements)

| Future vector ID | Mode | Single required stimulus / contrast | Expected local evidence |
|---|---|---|---|
| `3Z-V-C-01` | P | R1 exact domain + one NUL + eight BE length octets | `FRAME_MATCH`; admission DENIED |
| `3Z-V-C-02` | P | R2 exact domain + one NUL + eight BE length octets | `FRAME_MATCH`; admission DENIED |
| `3Z-V-C-03` | P | R3 exact domain + one NUL + eight BE length octets | `FRAME_MATCH`; admission DENIED |
| `3Z-V-C-04` | P | R5 exact domain + one NUL + eight BE length octets | `FRAME_MATCH`; admission DENIED |
| `3Z-V-C-05` | P | SHA256(frame) independently agrees for a locally valid R1 | `DIGEST_MATCH`; admission DENIED |
| `3Z-V-C-06` | P | Pure Ed25519 synthetic frame verification with supplied ephemeral key | `SIGNATURE_VALID_SYNTHETIC`; admission DENIED |
| `3Z-V-C-07` | N | V1 signing domain used for R1V2 subject | `FRAME_REJECT`; admission DENIED |
| `3Z-V-C-08` | N | Wrong case/alias of exact V2 domain | `FRAME_REJECT`; admission DENIED |
| `3Z-V-C-09` | N | Little-endian length or 4-byte length | `FRAME_REJECT`; admission DENIED |
| `3Z-V-C-10` | N | Asserted BE length differs from exact octet length of ASCII-only P | `FRAME_REJECT`; admission DENIED |
| `3Z-V-C-11` | N | Omitted, duplicate or shifted NUL separator | `FRAME_REJECT`; admission DENIED |
| `3Z-V-C-12` | N | SHA256(P) or SHA256(wrapper) substituted for SHA256(frame) | `DIGEST_REJECT`; admission DENIED |
| `3Z-V-C-13` | N | Ed25519 signature covers digest instead of frame | `SIGNATURE_REJECT`; admission DENIED |
| `3Z-V-C-14` | N | Ed25519ph/ctx, invalid key length or changed signature bit | `SIGNATURE_REJECT`; admission DENIED |

### 5.D — V-D: Acyclic references, rank and exact cross-object binding (16 planned requirements)

| Future vector ID | Mode | Single required stimulus / contrast | Expected local evidence |
|---|---|---|---|
| `3Z-V-D-01` | P | R2 root approval digest equals recomputed R1V2 body_sha256 | `GRAPH_MATCH_SYNTHETIC`; admission DENIED |
| `3Z-V-D-02` | P | R3 R1/R2 digests equal recomputed subject identities | `GRAPH_MATCH_SYNTHETIC`; admission DENIED |
| `3Z-V-D-03` | P | R5 R1/R2/R3 digests equal recomputed identities | `GRAPH_MATCH_SYNTHETIC`; admission DENIED |
| `3Z-V-D-04` | P | R1 PRIOR points to earlier R1V2 version and rank | `GRAPH_MATCH_SYNTHETIC`; admission DENIED |
| `3Z-V-D-05` | P | R5 PRIOR points to earlier approved R5V2 lineage in synthetic expected history | `GRAPH_MATCH_SYNTHETIC`; admission DENIED |
| `3Z-V-D-06` | N | R1 GENESIS inferred from absent predecessor | `GRAPH_REJECT`; admission DENIED |
| `3Z-V-D-07` | N | R5 PRIOR targets unapproved candidate | `GRAPH_REJECT`; admission DENIED |
| `3Z-V-D-08` | N | R1 PRIOR target contract is R2V2 not R1V2 | `GRAPH_REJECT`; admission DENIED |
| `3Z-V-D-09` | N | R5 PRIOR target contract is R1V2 not R5V2 | `GRAPH_REJECT`; admission DENIED |
| `3Z-V-D-10` | N | PRIOR target version is equal/future (not earlier) | `GRAPH_REJECT`; admission DENIED |
| `3Z-V-D-11` | N | R2 initial-source branch missing or both alternatives present | `SCHEMA_REJECT`; admission DENIED |
| `3Z-V-D-12` | N | Cross-generation V1 digest injected into R3V2 edge | `GRAPH_REJECT`; admission DENIED |
| `3Z-V-D-13` | N | One NS4 field differs between R1/R2/R3/R5 | `GRAPH_REJECT`; admission DENIED |
| `3Z-V-D-14` | N | R5 digest points to R4 custody receipt rather than sealed R3 | `GRAPH_REJECT`; admission DENIED |
| `3Z-V-D-15` | N | R3 signed body contains future R5/R6 reference | `GRAPH_REJECT`; admission DENIED |
| `3Z-V-D-16` | N | Cycle or same-rank back-edge in signed-body graph | `GRAPH_REJECT`; admission DENIED |

### 5.E — V-E: Detached external carrier and unavailable authority boundaries (12 planned requirements)

| Future vector ID | Mode | Single required stimulus / contrast | Expected local evidence |
|---|---|---|---|
| `3Z-V-E-01` | N | R0 claims independent root based solely on included self-declared key | `EXTERNAL_BLOCKED`; admission DENIED |
| `3Z-V-E-02` | N | R4 has sealed R3 digest but no independent custody history | `EXTERNAL_BLOCKED`; admission DENIED |
| `3Z-V-E-03` | N | R6 approval claims quorum but lacks independently authorized approvers | `EXTERNAL_BLOCKED`; admission DENIED |
| `3Z-V-E-04` | N | R7 treated as a custody receipt rather than subsequent signed floor subject | `EXTERNAL_BLOCKED`; admission DENIED |
| `3Z-V-E-05` | N | R8 proof asserts durable receipt but carries no protected history | `EXTERNAL_BLOCKED`; admission DENIED |
| `3Z-V-E-06` | N | Witness A supplied without distinct witness B | `EXTERNAL_BLOCKED`; admission DENIED |
| `3Z-V-E-07` | N | Witness B aliases A identity/root while claiming independence | `EXTERNAL_BLOCKED`; admission DENIED |
| `3Z-V-E-08` | N | Merkle inclusion asserted without exact CAUSAL leaf transcript | `EXTERNAL_BLOCKED`; admission DENIED |
| `3Z-V-E-09` | N | Inclusion path present but historical consistency proof missing | `EXTERNAL_BLOCKED`; admission DENIED |
| `3Z-V-E-10` | N | KAA authorization assembled from incompatible registry/revocation snapshots | `EXTERNAL_BLOCKED`; admission DENIED |
| `3Z-V-E-11` | N | Self-asserted issued_at timestamp used as trusted freshness | `EXTERNAL_BLOCKED`; admission DENIED |
| `3Z-V-E-12` | N | Source-prefix hash accepted without immutable capture evidence | `EXTERNAL_BLOCKED`; admission DENIED |

### 5.F — V-F: Rollback, forks, recovery, key/floor history (12 planned requirements)

| Future vector ID | Mode | Single required stimulus / contrast | Expected local evidence |
|---|---|---|---|
| `3Z-V-F-01` | N | Anchor counter decreases under same epoch | `GRAPH_REJECT`; admission DENIED |
| `3Z-V-F-02` | N | Anchor counter skips required predecessor with no authorized transition | `GRAPH_REJECT`; admission DENIED |
| `3Z-V-F-03` | N | Equal journal seq with two different event hashes | `GRAPH_REJECT`; admission DENIED |
| `3Z-V-F-04` | N | Root approval version rollback | `GRAPH_REJECT`; admission DENIED |
| `3Z-V-F-05` | N | Key revocation stale view at claimed issuance | `EXTERNAL_BLOCKED`; admission DENIED |
| `3Z-V-F-06` | N | Key revoked for scope; future claim tries to undo without authority | `EXTERNAL_BLOCKED`; admission DENIED |
| `3Z-V-F-07` | N | Root rotation resets counter or source epoch without authorization | `GRAPH_REJECT`; admission DENIED |
| `3Z-V-F-08` | N | Root recovery approved solely by compromised prior root | `EXTERNAL_BLOCKED`; admission DENIED |
| `3Z-V-F-09` | N | Witness head rolls back to older sequence | `EXTERNAL_BLOCKED`; admission DENIED |
| `3Z-V-F-10` | N | Witness same-size heads disagree | `EXTERNAL_BLOCKED`; admission DENIED |
| `3Z-V-F-11` | N | Protected trust floor decreases or forks at equal version | `EXTERNAL_BLOCKED`; admission DENIED |
| `3Z-V-F-12` | N | Later R7 signed body references future R8 receipt | `GRAPH_REJECT`; admission DENIED |

### 5.G — V-G: Cross-generation conflicts / no silent fallback (10 planned requirements)

| Future vector ID | Mode | Single required stimulus / contrast | Expected local evidence |
|---|---|---|---|
| `3Z-V-G-01` | N | V1 R1 contract with V2 signing domain | `SCHEMA_REJECT`; admission DENIED |
| `3Z-V-G-02` | N | V2 R5 with old previous_approved_activation_digest alias | `SCHEMA_REJECT`; admission DENIED |
| `3Z-V-G-03` | N | V2 R1 with old previous_root_approval_intent_digest alias | `SCHEMA_REJECT`; admission DENIED |
| `3Z-V-G-04` | N | Unknown BW-G3 contract auto-downgraded to G2 | `SCHEMA_REJECT`; admission DENIED |
| `3Z-V-G-05` | N | Unknown P1 carrier version treated as newest supported | `EXTERNAL_BLOCKED`; admission DENIED |
| `3Z-V-G-06` | N | Unknown digest-role silently reinterpreted as other target | `GRAPH_REJECT`; admission DENIED |
| `3Z-V-G-07` | N | V1 and V2 body hashes treated equivalent by matching semantic JSON | `GRAPH_REJECT`; admission DENIED |
| `3Z-V-G-08` | N | Generic carrier substituted for mandatory R4/R6 witness role | `EXTERNAL_BLOCKED`; admission DENIED |
| `3Z-V-G-09` | N | Fictitious root attestation sourced from local transport pin | `EXTERNAL_BLOCKED`; admission DENIED |
| `3Z-V-G-10` | N | Disagreement of independent implementations silently normalized | `ORACLE_BLOCKED`; admission DENIED |

### 5.H — V-H: Harness independence and bounds (future, no execution) (8 planned requirements)

| Future vector ID | Mode | Single required stimulus / contrast | Expected local evidence |
|---|---|---|---|
| `3Z-V-H-01` | N | Expected bytes are regenerated by the implementation under test | `ORACLE_BLOCKED`; admission DENIED |
| `3Z-V-H-02` | N | Two language wrappers share the same native canonicalizer | `ORACLE_BLOCKED`; admission DENIED |
| `3Z-V-H-03` | N | Vector misses input bytes, exact frame or independent oracle provenance | `ORACLE_BLOCKED`; admission DENIED |
| `3Z-V-H-04` | N | Same vector counted twice toward 102 unique cases | `ORACLE_BLOCKED`; admission DENIED |
| `3Z-V-H-05` | N | Invalid vector accepted locally but globally DENIED misclassified as PASS | `VERDICT_BLOCKED`; admission DENIED |
| `3Z-V-H-06` | N | Oversized/deep payload is treated as acceptable with unapproved resource policy | `RESOURCE_BLOCKED`; admission DENIED |
| `3Z-V-H-07` | P | Repeat same immutable vector yields identical exact result and no mutation | `DETERMINISM_EXPECTED`; admission DENIED |
| `3Z-V-H-08` | P | Synthetic-only future harness remains no I/O/no RS→ES→ORC and trusted DENIED | `ISOLATION_EXPECTED`; admission DENIED |

### 5.1. Counting, source allocation and blocked cases

Group totals: **V-A 14 + V-B 16 + V-C 14 + V-D 16 + V-E 12 + V-F 12 + V-G 10 + V-H 8 = exactly 102** unique *planned requirements*. No input JSON file, hex frame, digest, signature or independently verified expected output exists as a result of Phase 3Z. Accordingly actual vectors: **0**; executed conformance: **0**; golden-vector PASS: **0**.

An authorized later corpus may add more cases but must not relabel one specimen as two unique IDs. A `P` planning case expecting local syntactic validity may still have `external_provenance=NOT_VERIFIED`, `trusted_admission=DENIED`. For E/F carrier rows, an exact proof-wire parser is `P0-BLOCKED`; future executable expectations remain proposed diagnostics, not runnable current assertions.

## 6. Full source-scenario trace obligation (not executable mapping)

Source families are **individually identified** in their accepted documents. The next separately authorized corpus-production phase SHALL provide a machine-reviewable matrix with one row per source scenario and explicit `future_vector_id` references (many scenarios may map to the same unique case; one scenario may require several variants):

| Controlling source | Individual source IDs required in mapping | Count | Candidate primary V coverage |
|---|---|---:|---|
| Phase 3S | `3S-SC-01…30` | 30 | A, D, E, F, G |
| Phase 3V | `3V-SC-01…18` | 18 | A, D, E, G |
| Phase 3W | `3W-SC-01…20` | 20 | A, C, D, E, G |
| Phase 3X | `3X-SC-01…24` | 24 | B, C, D, E, F, G |
| Phase 3Y | `3Y-SC-01…24` | 24 | B, C, D, E, G, H |
| **Total obligations** | 116 distinct source scenario IDs | **116** | Overlapping coverage; not 116 additional unique vectors |

**Unambiguous trace-check requirement:** an acceptance check must enumerate all five ranges with no gaps, prove every source ID has at least one independently reviewed future vector/specimen, and demonstrate the mapped vector actually tests that source scenario's expected failure or allowed behavior. Merely labeling an entire range as “covered by V-D” is **insufficient**; current table is a planning allocation, **not** that completed case-by-case mapping. Where one row's stimulus does not capture the complete source scenario, write an additional vector requirement rather than silently close coverage. Records must preserve source scenario text, origin-document SHA-256, expected local diagnostic and rationale for mapping.

Also retain exact `3M-RV-18…24` as P0 and 3Y `Y-G0…G8` as future gate context, not claim that vector trace closes any P0.

## 7. Cross-language and independently adjudicated oracle criteria

1. **Independent implementation families:** at least two different languages and independent implementations of parsing, schema/type checks, JCS and frame construction. Shared native serialization/canonicalization library, embedded runtime or generated implementation = a single family for the critical path. Independence review must include authoring, dependencies, binaries and source lineage, not only language names.
2. **Independent expectation authoring:** a separate oracle reviewer curates reference hex, lengths, frames, digests and signature outcomes from independent specifications and reference evidence. Expected values cannot originate exclusively in the implementation-under-test. A third independent standards-derived source adjudicates discrepancies; not a 2-of-3 majority acceptance rule.
3. **Byte-level comparison:** input raw bytes, P, domain ASCII, separator, 8-byte BE length, frame and hash compared *exactly*. Compare signature verification verdict and diagnostic stages. Semantic JSON equality or both returning DENIED is insufficient.
4. **Separate success axes:** locally structurally valid ≠ signature correct under synthetic key ≠ externally authenticated ≠ trusted admission. No test grants authority because its `expected_*` fields claim it.
5. **Disagreement handling:** any divergence or unresolved oracle discrepancy is `CONFORMANCE_BLOCKED`; record both outputs and environment, no auto-normalization, permissive fallback, 'latest-wins' or tacit changes to expected data.
6. **Key and resource policy:** no private or public test key material chosen or generated in Phase 3Z. Future synthetic-only keys ephemeral, single-purpose and never used as real trust anchors. Limits for max JSON bytes, max nesting, vector count, proof size, history depth and execution budget await RV-24; unknown limits are a blocker, not unlimited permission.
7. **Reproducibility & lineage:** future manifest must record runtime/compiler/crypto library versions, exact input hashes, expected-output file hashes, review signatures if independently authorized, separate reviewer sign-off, deterministic generation procedure and candidate-scope pin. No release of corpus is valid with `reviewer_signoff_state` falsely promoted from `NOT_REVIEWED`.
8. **Strict isolation:** no filesystem/network use inside future pure verifier; optional outer test-file loading only if separately PO authorized and isolated; never access production `C:\CAUSAL 2.0`, any real keys, Journal/BlobStore or downstream RS→ES→ORC. A synthetic verifier must not implement `trusted_admission=GRANTED`.

## 8. Independent proof-carrier boundary: 13/13 still P0-blocked

The names below are *candidate Phase 3W/3X P1 profile identifiers*, not registered or authorized provider formats. The quartet synthetic corpus covers **no actual independently validated carrier**.

| Family | Proposed profile | Missing independent evidence | Blocker |
|---|---|---|---|
| R0 | `CAUSAL-EXT-ROOT-POLICY-P1` | independent root bootstrap/quorum/recovery | P0 RV-20/24 |
| R4 | `CAUSAL-EXT-INITIAL-FLOOR-RECEIPT-P1` | sealed R3 custody/monotonic receipt | P0 RV-21/23/24 |
| R6 | `CAUSAL-EXT-ACTIVATION-APPROVAL-P1` | sealed R5 and independent approval quorum | P0 RV-20/24 |
| R7 | `CAUSAL-EXT-SUBSEQUENT-FLOOR-P1` | subsequent *signed floor subject*; no embedded R8 | P0 RV-18/19/23 |
| R8 | `CAUSAL-EXT-FLOOR-RECEIPT-P1` | sealed R7 durable external custody | P0 RV-23/24 |
| Witness A | `CAUSAL-EXT-WITNESS-A-P1` | signed head plus inclusion/consistency with independent witness A | P0 RV-19/20 |
| Witness B | `CAUSAL-EXT-WITNESS-B-P1` | separate authenticated witness B and proof chain | P0 RV-19/20 |
| KAA | `CAUSAL-EXT-KAA-STATE-P1` | coherent delegation/revocation/rotation at issuance | P0 RV-18/20/21 |
| Time | `CAUSAL-EXT-TIME-P1` | independently authenticated freshness bound | P0 RV-21 |
| Snapshot | `CAUSAL-EXT-SOURCE-SNAPSHOT-P1` | immutable exact prefix+closure capture/TOCTOU | P0 RV-22/24 |
| Signer | `CAUSAL-EXT-SIGNER-ISSUANCE-P1` | issuer inspection/authorization against exact capture | P0 RV-20/22/24 |
| Anchor | `CAUSAL-EXT-ANCHOR-CARRIER-P1` | unchanged AnchorPayloadV1 and external signer authorization | P0 RV-18/20 |
| Composite | `CAUSAL-EXT-COMPOSITE-BUNDLE-P1` | externally approved full membership and proof linkage | P0 RV-18/24 |

R7 is **not** a detached receipt. R4→sealed R3V2, R6→sealed R5V2 and R8→sealed R7 are detached evidence links; none may appear as a future-digest field in their earlier signed subject. Witness inclusion and consistency bytes, their independent authorization and preapproved external historical heads remain unverified. Unknown proof profile, self-declared issuer, missing external floor/time/capture or generic-path substitution must be classified `UNVERIFIED / DENIED` or explicit structural rejection. This corpus cannot close RV-19/20/21/22/23/24 by design.

## 9. Specific future execution and corpus acceptance gates — ALL NOT AUTHORIZED NOW

| Gate | Minimum evidence before possible next PO decision | Current status |
|---|---|---|
| `3Z-G0` | PO acceptance of this requirements-only Phase 3Z review | PENDING |
| `3Z-G1` | Narrowly scoped, versioned synthetic test-profile change record for quartet (not full schema freeze) and exact resource limits | NOT AUTHORIZED; RV-18/24 open |
| `3Z-G2` | Independent oracle protocol, implementations/languages selected and conflict-of-interest declaration | NOT AUTHORIZED |
| `3Z-G3` | **Separate PO GO** to generate only synthetic bytes/ephemeral test keys and specimen corpus | NOT AUTHORIZED |
| `3Z-G4` | Corpus with >=102 independent unique case records + all 116 source-scenario mappings, separately reviewed exact expected outputs | NOT CREATED |
| `3Z-G5` | **Separate PO GO** to execute cross-language tests in isolated offline environment | NOT AUTHORIZED |
| `3Z-G6` | Audited independent differential results incl. rejection stages and byte agreement, discrepancies resolved by review | NOT TESTED |
| `3Z-G7` | Full carrier IDL, proof algorithm/byte transcripts, independent witness and trust roots, protected floor/time/snapshot, adversarial review | P0 OPEN / NOT VERIFIED |
| `3Z-G8` | Separate final schema freeze / trusted integration / autonomous execution PO decisions | NOT AUTHORIZED / NO-GO |

**Proposed minimal next step after 3Z acceptance:** a **separate design-only fixture/oracle adjudication review** to settle exact corpus record branches and owner/reviewer independence. Even if PO later authorizes actual synthetic vector generation, that alone must not authorize conformance execution or mark schema as frozen.

## 10. Proposed negative review scenarios `3Z-SC-01…20` — SPECIFIED, NOT EXECUTED

| ID | Future failure condition | Expected classification |
|---|---|---|
| 01 | Oracle expected frame comes solely from target implementation | `VECTOR_ORACLE_NOT_INDEPENDENT` |
| 02 | Two languages call same native canonicalization library | `INDEPENDENCE_NOT_ESTABLISHED` |
| 03 | Negative parse vector supplies fabricated expected signature PASS | `VECTOR_INCOMPLETE` |
| 04 | `NOT_APPLICABLE` silently converted into empty byte string | `VECTOR_INCOMPLETE` |
| 05 | Input hex missing but semantic JSON provided | `VECTOR_INCOMPLETE` |
| 06 | Corpus lacks exact PO source pin / profile digest | `REFERENCE_DRIFT` |
| 07 | Two case IDs share one specimen counted twice to meet 102 | `COVERAGE_INFLATED` |
| 08 | A source `3S/3V/3W/3X/3Y` case left unmapped | `COVERAGE_INCOMPLETE` |
| 09 | `FRAME` digest calculated over P only but compared as correct | `BODY_DIGEST_MISMATCH` |
| 10 | Signed subject transport whitespace incorrectly rejects canonical P equivalence | `CANONICAL_BYTES_INVALID` (test verdict mismatch) |
| 11 | Hex digest differs only in uppercase case but is accepted | `SCHEMA_UNSUPPORTED` |
| 12 | Synthetic signature over SHA-256(frame) accepted as pure Ed25519(frame) | `SIGNATURE_INVALID` |
| 13 | Exact `GENESIS` predecessor self-authorizes first root | `GENESIS_NOT_AUTHORIZED` |
| 14 | A valid local synthetic quartet automatically grants provenance | `TRUSTED_ADMISSION_NOT_AUTHORIZED` |
| 15 | Phase 3H `AnchorPayloadV1` silently imported as BW-G2 R1V2 | `SCHEMA_UNSUPPORTED` |
| 16 | Missing R4 external custody proof is replaced by a digest claim | `PROOF_PROFILE_UNSUPPORTED` |
| 17 | Two witness labels share same issuer/operator | `WITNESS_INDEPENDENCE_UNVERIFIED` |
| 18 | Unapproved huge vector accepted because uint64 length accommodates it | `RESOURCE_POLICY_UNRESOLVED` |
| 19 | Local parse error is ignored because admission is DENIED anyway | `CONFORMANCE_BLOCKED` |
| 20 | Future no-GO gate skipped after synthetic corpus success | `TRUSTED_ADMISSION_NOT_AUTHORIZED` |

All scenario expected codes are **candidate** diagnostic requirements; not verified outputs of actual software. A testing budget is not authorized under Phase 3Z.

## 11. Phase 3Z design-review checklist (`3Z-RV-01…30`) — NOT TEST EXECUTION

| ID | Review criterion | Required review disposition |
|---|---|---|
| 01 | Explicit PO 3Z DESIGN-ONLY scope preserved | Confirm |
| 02 | 3Y acceptance recorded; BW-G2 not frozen | Confirm |
| 03 | Four V2 contracts/domains and 14/13/12/13 key counts unchanged | Confirm |
| 04 | Exactly two field renames; no V1/V2 aliases | Confirm |
| 05 | NS4 expected out-of-band and closed tagged branches | Confirm |
| 06 | Raw UTF-8 JSON and lexical integer rejection specified | Confirm |
| 07 | Canonical `P` JCS bytes distinguished from transport | Confirm |
| 08 | Exact ASCII domain, NUL and 8-byte BE length | Confirm |
| 09 | SHA-256 of *frame*, not payload/wrapper | Confirm |
| 10 | Pure Ed25519 on frame; no prehash/ctx/ph | Confirm |
| 11 | Signature/public key shape and ephemeral-only provenance | Confirm |
| 12 | Frozen AnchorPayloadV1 unchanged | Confirm |
| 13 | Manifest requirements include exact source pins/profile/inventory digests | Confirm |
| 14 | Per-vector exact hex input/P/frame/digest/signature fields required | Confirm |
| 15 | Parse-invalid vector NOT_APPLICABLE branch specified, no fake bytes | Confirm |
| 16 | Error stage and independent diagnostic required for negatives | Confirm |
| 17 | Count totals 14/16/14/16/12/12/10/8 = 102 unique IDs | Confirm |
| 18 | Distinguish 102 planned IDs from 0 actual vectors | Confirm |
| 19 | Full mapping obligations cover 30+18+20+24+24=116 source scenarios | Confirm |
| 20 | Full case-by-case trace is deferred, not falsely claimed complete | Confirm |
| 21 | At least two independently implemented languages required later | Confirm |
| 22 | Independent curated oracle and discrepancy block required later | Confirm |
| 23 | Differential comparison tests bytes, not semantic JSON only | Confirm |
| 24 | No I/O, production modules or downstream path in future pure tests | Confirm |
| 25 | All 13 carrier families remain P0-BLOCKED; R7 subject not receipt | Confirm |
| 26 | All 20 `3Z-SC` conditions described, none executed | Confirm |
| 27 | No real root, provider, Journal, BlobStore, keys or tests produced | Confirm |
| 28 | 3M-RV-18…24 all P0 OPEN; 3Q-CR-01 proposed | Confirm |
| 29 | Separate gates for corpus writing, test execution, freeze and trusted GO | Confirm |
| 30 | `trusted_admission=DENIED`, trusted implementation and autonomy NO-GO | Confirm |

Acceptance of checklist means the requirements are *written*, not that a verifier exists, that all values are independently computed or that any carrier proof is valid. PO acceptance should identify any unresolved wording without silently adding authority.

## 12. P0 and status ledger (not changed by design review)

| Object / blocker | Status |
|---|---|
| Phase 3Y | `CLOSED / ACCEPTED` (PO) |
| **Phase 3Z** | **`REVIEW PREPARED / AWAITING PO ACCEPTANCE`** |
| BW-G2 | `DESIGN PROPOSED / NOT FROZEN` |
| 3Q-CR-01 | `DESIGN RESOLUTION PROPOSED` |
| 3M-RV-18 | `P0 / OPEN`: final wire IDL/transport and vectors |
| 3M-RV-19 | `P0 / OPEN`: witness proof byte transcripts and crypto vectors |
| 3M-RV-20 | `P0 / OPEN`: independent bootstrap, root/approval authority |
| 3M-RV-21 | `P0 / OPEN`: independently verified time/revocation freshness |
| 3M-RV-22 | `P0 / OPEN`: immutable snapshot and TOCTOU proof |
| 3M-RV-23 | `P0 / OPEN`: durable independent floor/custody receipts |
| 3M-RV-24 | `P0 / OPEN`: resources, custody, adversarial review |
| Composite Evidence Schema, Trust Anchor v0.1, Key Authorization v0.1 | `REVIEW ACCEPTED / NOT FROZEN` |
| ResearchState, Experiment Selection, Research Orchestrator v1.0 | `FROZEN / UNCHANGED` |
| Synthetic golden vectors instantiated / cryptographic tests executed | **0 / 0** |
| External trust anchors / provenance | `NOT VERIFIED` |
| Trusted admission | `DENIED` |
| Trusted implementation | `NO-GO` |
| Autonomous execution | `NO-GO` |
| Production changes | `NONE` |

## 13. Proposed PO decision text

> **Phase 3Z — RECOMMENDED FOR ACCEPTANCE solely as DESIGN-ONLY / REVIEW.** The BW-G2 Synthetic Golden Vector Specification v0.1 specifies a 102-case *future* inventory and separate exact-byte/oracle requirements. **No** vectors, keys, signatures, machine verifier, executable schemas or tests have been created, and no P0 has been closed. BW-G2 remains DESIGN PROPOSED / NOT FROZEN; 3Q-CR-01 remains DESIGN RESOLUTION PROPOSED; all 3M-RV-18…24 remain P0 OPEN; trusted admission DENIED, trusted implementation NO-GO, autonomous execution NO-GO. Any subsequent fixture generation, differential test execution or schema freeze requires a separate PO authorization.

