# CAUSAL 2.0 — Phase 3AB / Fixture Machine Structure & Reference Control Review v0.1

**Artifact:** `Fixture Machine Structure & Reference Control Review`  
**Decision class:** `DESIGN-ONLY / REVIEW`  
**Phase state:** `REVIEW PREPARED / AWAITING PO ACCEPTANCE`  
**PO baseline:** Phase 3AA `CLOSED / ACCEPTED`; Phase 3AB `AUTHORIZED / GO` (2026-10-30).  
**Evidence class:** design review; **no actual fixture, golden bytes, private/public key, signature, verifier, conformance run, external proof or trusted approval was created**.

> **Immutable boundary.** `BW-G2=DESIGN PROPOSED / NOT FROZEN`; `3Q-CR-01=DESIGN RESOLUTION PROPOSED`; `3M-RV-18…24=P0 / OPEN` (7/7); Composite Evidence Schema, Trust Anchor Contract v0.1 and Key Authorization Contract v0.1 remain `REVIEW ACCEPTED / NOT FROZEN`. ResearchState / Experiment Selection / Research Orchestrator v1.0 remain `FROZEN / UNCHANGED`. Production code, `C:\CAUSAL 2.0`, Oracle, PPO, real keys/roots/witnesses/Journal/BlobStore, and RS→ES→ORC are out of scope. `trusted_admission=DENIED`, `trusted_implementation=NO-GO`, `autonomous_execution=NO-GO`.

## 0. Executive decision — close design proliferation, not trust gates

Phase 3AB selects a **single proposed closed machine-structure profile** for a future synthetic corpus, `CAUSAL-BWG2-FIXTURE-CANDIDATE-3AB-v1` (hereafter **FCP-3AB/1**), and a detached independent reference-control process. This selection is **documentary**, NOT a schema freeze, approval of generated vectors, issue of keys, or permission to execute. FCP-3AB/1 is a *fixture container* proposal, separate from the **BW-G2 subject wire protocol** and its not-frozen `R1V2/R2V2/R3V2/R5V2` quartet.

| Decision | Candidate resolution | Gate not crossed |
|---|---|---|
| `3AB-D-01` | Closed manifest `M`, case fixture `F`, separate oracle transcript `T`, trace map `X` and detached approvals `A` | No instance of any record is created |
| `3AB-D-02` | A stimulus subobject is independently digestible **before** an oracle transcript exists | No cyclic `F ↔ T` references |
| `3AB-D-03` | Four closed case kinds; exact stage-result tagged union with no implicit nulls or fake bytes | `DENIED` alone never passes a stage test |
| `3AB-D-04` | JCS canonical container sealing; hash exact canonical JSON bytes, input raw transport retained as lowercase hex | No current corpus or approved fixture profile |
| `3AB-D-05` | Detached role-separated reference approval and corpus release, with supersession rather than in-place edits | No self-approved oracle, no external authority |
| `3AB-D-06` | Separate counts for 102 requirements, byte-bearing specimens, P0-blocked cases and actual passed tests | No false claim of 102 completed golden vectors |
| `3AB-D-07` | Finish design cycle after this review; ask PO separately for *limited offline creation* | `3AC` / any build is NOT AUTHORIZED |

**Documentary disposition:** future fixture-schema profile may be reviewed as a *candidate complete IDL*; final effective ratification of even this narrow fixture profile is a separate PO decision. Nothing in this document closes any of the seven production-trust P0 criteria.

## 1. Source basis, precedence and pinned identities

Latest explicit PO restrictions take precedence; frozen scientific v1.0 contracts are untouched; accepted but non-frozen design documents define **candidate** semantics only. Source pins below are exact local SHA-256 observations, **not** external provenance claims.

| Document | SHA-256 |
|---|---|
| Phase 3W typed reference / carrier review | `7fb4f71de909e886ac7675dce9fcd531edd199df61a6b7e2a00b5b43dfe7db9c` |
| Phase 3X byte/profile review | `78f331c689df4f4ae47a8e1d1c0657c1d9abdd25465eb2c1e53ec62c44244797` |
| Phase 3Y cross-language readiness | `079e4996f0a7e50a1002e4e5d2c5717e6d3a611298d664020cc7866aad6d7604` |
| Phase 3Z synthetic golden-vector specification | `ec5e8a2466d1cbc99ab3897b52faa1cfb9a773b318620f2a1d4a9baecd54026a` |
| Phase 3AA fixture format / approval review | `29d4571014f36a48b161b8a47523b0cab81b3bae2902b3a87618bf1b16348bcf` |

No implicit `latest` file, unpinned schema alias, migration from Phase 3H V1, or automatic retroactive amendment is allowed. A corpus manifest would retain these exact pins and PO acceptance references in future *if separately authorized*.

## 2. Boundary: a fixture is test evidence, never a signed research authority

**BW-G2 candidate signed-body quartet (unchanged):** `RootApprovalIntentV2` (R1V2, 14 keys, `CAUSAL-KAA-ROOT-INTENT-v2`); `GenesisApprovalV2` (R2V2, 13 keys, `CAUSAL-KAA-GENESIS-APPROVAL-v2`); `InitialFloorCommitmentV2` (R3V2, 12 keys, `CAUSAL-TRUST-INITIAL-FLOOR-v2`); `BootstrapActivationCandidateV2` (R5V2, 13 keys, `CAUSAL-KAA-BOOTSTRAP-ACTIVATION-v2`). Only the candidate R1 and R5 previous-reference keys were renamed from `*_digest` to `*_ref`, both with a closed `GENESIS | PRIOR` tagged union. This is still **BW-G2 DESIGN PROPOSED**, not amended/frozen contracts.

The proposed future *subject* byte rule, referenced but **not executed** here:

```text
P                 := UTF8(RFC8785_JCS(validated_BW_G2_signed_body))
frame             := ASCII(exact_subject_domain) || 0x00 || uint64_be(octet_length(P)) || P
body_sha256       := lowercase_hex(SHA256(frame))
synthetic_sig     := PureEd25519.Sign(test_only_key, frame)   # separate future PO gate
```

The fixture container has a **different** version/profile and its own sealing digest; its keys do **not** enter `P` and must never be added to R1/R2/R3/R5 signed bodies. An `expected_ns` is only independently supplied *synthetic test context*, not an independently provisioned live namespace. A synthetic Ed25519 match does not prove key authorization, witness, freshness, source provenance, or admission.

## 3. FCP-3AB/1 proposed machine types and canonical transport

This is an **IDL in human-readable tables**, not an executable JSON Schema, generated fixture, signed assertion, or verifier. Names and exact branch shapes below are selected *for future ratification*, not installed into production.

**Primitive candidate types:**

| Name | Machine meaning and restriction |
|---|---|
| `ASCII_ID` | ASCII case-sensitive ID, `^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$`; no paths/URLs or case folding |
| `DIGEST32_HEX` | Exactly 64 lowercase ASCII hex characters for SHA-256 bytes; object-type/domain checked separately |
| `OCTETS_HEX` | Even-length lowercase hex; may be zero bytes **only when an explicitly valid raw input is zero bytes**, never used as missing-state marker |
| `U53` | JSON integer in `[0, 9007199254740991]`; boolean, float, exponent, `-0`, coercion forbidden; semantic fields may require `>0` |
| `STRING_ENUM` | One of the declared exact literals, no aliases or unrecognized values |
| `NS4` | Closed object `{project_id,journal_id,source_epoch,policy_id}` with 4 case-sensitive fields, scoped types per candidate BW-G2; synthetic expected namespace only |
| `DIGESTED_REF` | Closed `{object_type, object_version, signing_domain, digest}` to an already specified exact subject; no `latest` or file-path substitution |
| `ARRAY<T>` | Ordered, unique where identity-bearing, no implicit sort except declared deterministic manifest order |

**Container serialization:** single strict UTF-8 JSON object, no BOM, duplicate keys at any depth, unpaired surrogates, nonfinite numbers, `null`, or unknown keys; no comments or trailing data. Container strings for IDs and control enums are ASCII; byte payloads are `OCTETS_HEX`. Human narratives, independent-review notes, dependency reports and timestamps belong in detached review evidence, not BW-G2 signed bodies. When a future record becomes *sealed*, bytes are `UTF8(RFC8785_JCS(record_without_self_digest))`; a seal is `SHA256` of those exact bytes. Raw BW-G2 input bytes remain **unmodified inside** `input_json_utf8_hex`, including intentionally malformed JSON and whitespace. Sealing the *container* does not normalize the embedded raw bytes.

**Resource bounds:** `U53` is a format-level numeric bound, **not** a safe consumption limit. Exact maximum fixture/manifest bytes, input length, nesting depth, number of entries and oracle transcript length must be independently ratified under `3M-RV-24` **before** any machine execution. Until then `execution_ready=false` for all cases. Never interpret a large but well-typed count as authorized allocation.

### 3.1. Artifact M — closed CorpusManifestCandidate

Each listed field is required, with **no optional extras**:

| Field | Type | Invariant |
|---|---|---|
| `manifest_profile_id` | exact literal `CAUSAL-BWG2-FIXTURE-CANDIDATE-3AB-v1` | Distinct from BW-G2 subject version |
| `corpus_id` | `ASCII_ID` | No implicit latest |
| `corpus_revision` | `U53 (>0)` | Monotonic explicit version |
| `bw_profile_id` | exact `BW-G2` | `protocol_frozen=false` |
| `protocol_frozen` | exact `false` | No schema freeze claims |
| `synthetic_marker` | exact `UNTRUSTED` | Mandatory |
| `corpus_kind` | exact `SYNTHETIC_TEST_ONLY` | Mandatory |
| `source_pins` | nonempty array of closed `{phase,document_id,sha256,po_acceptance_ref}` | Exact pinned inputs, includes 3Z and 3AA, all refs documentary |
| `policy_refs` | closed `{oracle_method_id,independence_policy_id,resource_policy_id,fixture_profile_revision}` | Policy identity, not proof it was approved |
| `case_id_order` | array of 102 exact unique `3Z-V-*-NN` IDs | Order is explicitly declared, not filesystem order |
| `case_entries` | 102 closed `{vector_id,primary_group,case_kind,fixture_sha256,oracle_sha256}` | Exact F/T identities, not embedded approval flags |
| `group_expected_counts` | exact closed map V-A:14, V-B:16, V-C:14, V-D:16, V-E:12, V-F:12, V-G:10, V-H:8 | Sum 102; counts are expected **inventory**, not PASS |
| `scenario_trace_sha256` | `DIGEST32_HEX` | Exact detached X record hash; 116 source scenario IDs individually |
| `predecessor` | tagged `FIRST_CORPUS` or `SUPERSEDES` with prior sealed M digest + reason | No overwrite, no rollback |
| `expected_external_provenance` | exact `NOT_VERIFIED` | Not source authentication |
| `expected_trusted_admission` | exact `DENIED` | Never GRANTED |
| `expected_downstream_invoked` | exact `false` | No RS/ES/ORC |
| `manifest_lifecycle` | exact `CANDIDATE_UNAPPROVED` | Approvals remain detached; never update M in place |

**Important refinement of 3AA:** M must **not** contain a cryptographic `approval_ledger_ref`, per-case actual approval state, its own digest or eventual `approval_record_digest`. These are detached release records **after** M is sealed. Any previous `approval_ledger_ref` proposal is superseded **within this 3AB candidate only**, not silently changed in the accepted 3AA document. If a reviewer requires approval status, it is resolved from the independently verified detached ledger, not from M.

### 3.2. Artifact F — closed FixtureRecordCandidate

| Field | Type | Invariant |
|---|---|---|
| `fixture_profile_id` | exact `CAUSAL-BWG2-FIXTURE-CANDIDATE-3AB-v1` | No other profile accepted |
| `vector_id` | exact one ID from M | Unique and matches M |
| `revision` | `U53 (>0)` | Immutable per revision |
| `primary_group` | `V-A…V-H` | Exactly one |
| `case_kind` | `BYTE_POSITIVE`, `BYTE_NEGATIVE`, `EXTERNAL_BOUNDARY`, `HARNESS_GOVERNANCE` | Closed discriminant |
| `requirement_ref` | exact `3Z` case requirement ID | Full trace needed |
| `subject` | closed `BW_G2_SUBJECT` / `EXTERNAL_PROFILE` / `HARNESS_ONLY` union | Subject identity separate from raw payload |
| `stimulus` | closed `RAW_JSON` / `NO_INPUT` union | Exact original bytes or explicit no-input reason |
| `stimulus_sha256` | `DIGEST32_HEX` | Hash of JCS(stimulus identity subobject), see §4 |
| `oracle_transcript_sha256` | `DIGEST32_HEX` | Detached T, never self-calculated target ground truth |
| `expected` | closed `ExpectedStages` | Eight total stage slots, plus exact first reject and issue codes |
| `source_pins_sha256` | `DIGEST32_HEX` | Hash of sealed source-pin list, not a trust anchor |
| `source_scenario_refs` | unique ordered array of exact source scenario IDs | No range-only placeholders |
| `cross_case_dependencies` | unique array of exact vector IDs, lower rank | Acyclic; no forward/self refs |
| `synthetic_marker` | exact `UNTRUSTED` | Mandatory |
| `expected_external_provenance` | exact `NOT_VERIFIED` | Mandatory |
| `expected_trusted_admission` | exact `DENIED` | Mandatory |
| `expected_downstream_invoked` | exact `false` | Mandatory |

**`subject` closed branches:** `BW_G2_SUBJECT={kind,subject_contract,subject_domain,expected_ns}` for one of the *four* explicitly allowed V2 contracts with exact domain; `EXTERNAL_PROFILE={kind,carrier_family_id,p0_blocker_id,expected_ns}`; `HARNESS_ONLY={kind,policy_requirement_id}`. A case testing an invalid claimed contract keeps its **expected** contract in `subject` and places the invalid claimed bytes in `stimulus`. No subject branch authorizes any issuer.

**`stimulus` closed branches:** `RAW_JSON={kind,input_json_utf8_hex,input_byte_count,input_origin_id}`; `NO_INPUT={kind,no_input_reason,requirement_ref}`. For `RAW_JSON`, `input_byte_count` equals decoded octets exactly (including malformed JSON). `NO_INPUT` is for pure carrier-boundary or governance scenarios; it is **never** a string `""`, `null`, missing input, or invented valid signed body. `stimulus_sha256 = SHA256(UTF8(JCS(stimulus)))` on the **closed** stimulus object; this digest is not a body hash and must never be treated as one.

### 3.3. Artifact F.expected — mandatory stage-result discriminated union

`expected` contains exactly these eight slots: `parse`, `schema`, `canonical`, `frame`, `digest`, `synthetic_signature`, `typed_linkage`, `external_proof`; additionally `first_reject_stage` (exact stage label or `NONE`) and `issue_codes` (unique ordered array of versioned proposed codes). Every slot has **exactly one** branch:

| Branch `state` | Required and only payload fields | Meaning |
|---|---|---|
| `EXPECTED_BYTES` | `stage`, `bytes_hex`, `byte_count`, `algorithm_id`, `oracle_transcript_sha256` | Exact future independently approved bytes, stage reachable |
| `EXPECTED_VERDICT` | `stage`, `verdict`, `issue_code`, `oracle_transcript_sha256` | Stage with no byte result, including first rejection |
| `NOT_APPLICABLE` | `stage`, `because_stage`, `reason_code` | This case has no such stage or prior reject prevents operation |
| `NOT_EVALUATED` | `stage`, `stopped_at_stage`, `reason_code` | Potentially applicable but blocked by an earlier stop |
| `P0_BLOCKED` | `stage`, `p0_id`, `carrier_family_id`, `missing_evidence_class` | Only genuine external proof gap; no simulated proof success |

**Rules:** no `null`, absent slot, empty fabricated bytes, mixed branch payloads, unknown state or overridden safety fields. A parse-invalid case has `EXPECTED_VERDICT` at `parse` and downstream `NOT_APPLICABLE`/`NOT_EVALUATED`, never expected signature bytes. `BYTE_POSITIVE` requires exact independently approved canonical/frame/digest bytes when later instantiated; if signature is applicable, synthetic signature expectations require an explicitly approved reproducible **test-only** key policy (currently OPEN). `BYTE_NEGATIVE` requires first decisive rejection stage, including earlier-stage bytes **only if independently derived and reachable**. `EXTERNAL_BOUNDARY` requires a `P0_BLOCKED` external proof branch. `HARNESS_GOVERNANCE` demands a governance verdict and does not become a cryptographic PASS. Expected `DENIED` is constant independently of these local stage outcomes.

Where a stage is byte-bearing, its exact octet count and algorithm are stage-constrained: canonical = RFC8785/JCS UTF-8 payload; frame = domain+NUL+uint64BE+P; digest = 32 bytes of `SHA256(frame)`; synthetic signature = 64 bytes of Pure Ed25519 over the **frame**, with 32-byte synthetic public key recorded **in independent T evidence** under a future approved test-key rule. These conditions do not supply actual byte values. Parser/schema/linkage diagnostics are `EXPECTED_VERDICT`, not invented byte encodings.

### 3.4. Artifact T — independent OracleTranscriptCandidate

Closed candidate fields: `transcript_profile_id`, `transcript_id`, `vector_id`, `stimulus_sha256`, `subject_expected_contract`, `subject_expected_domain`, `source_pins_sha256`, `oracle_method_id`, `derivation_origin_ref`, `derivation_toolchain_disclosure_ref`, `independent_curator_role_ref`, `reference_stage_results`, `synthetic_key_policy_ref`, `cross_language_comparison_ref`, `discrepancy_refs`, `transcript_revision`, `synthetic_marker=UNTRUSTED`.

T is computed *from a pinned stimulus*, not from target verifier output. It references **`stimulus_sha256`**, never the final F digest, M digest or A approval. `reference_stage_results` use the same five-branch stage-result vocabulary as F and retain exact intermediate octets, algorithms and stage diagnostics where reachable. F may refer to **T's sealed digest** only after independent derivation. `derivation_origin_ref` and toolchain disclosure are substantive future evidence, not `VERIFIED` simply because fields are filled. No T record or oracle is created by this review.

### 3.5. Artifact X — detached SourceScenarioTraceCandidate

Closed candidate fields: `trace_profile_id`, `source_scenario_id`, `source_document_sha256`, `mapped_vector_ids` (nonempty unique array), `shared_stimulus_explanation`, `diagnostic_compatibility`, `mapping_review_state`, `synthetic_marker=UNTRUSTED`. The complete X set must enumerate each of **116** individual source scenario IDs: 3S (30), 3V (18), 3W (20), 3X (24), 3Y (24), with no range-only acceptance. X references existing vector **IDs**, not sealed M or detached approval records. Coverage is traceability, not execution evidence. Any unmapped scenario blocks future corpus release.

### 3.6. Artifact A — detached ReferenceApprovalCandidate and CorpusReleaseCandidate

`ReferenceApprovalCandidate` closed proposed fields: `approval_profile_id`, `approval_id`, `vector_id`, `fixture_sha256`, `oracle_sha256`, `reference_method_id`, `fixture_producer_role_ref`, `reference_curator_role_ref`, `independent_reviewer_role_ref`, `dependency_independence_evidence_ref`, `byte_comparison_state`, `issue_adjudication_refs`, `decision`, `decision_scope`, `approval_revision`, `synthetic_marker`. Allowed `decision`: `PENDING`, `APPROVE_REFERENCE`, `REJECT_REFERENCE`, `DISPUTED`, `BLOCKED_BY_P0`, `WITHDRAWN`. `decision_scope` always `SYNTHETIC_REFERENCE_ONLY`.

`CorpusReleaseCandidate` closed proposed fields: `release_profile_id`, `release_id`, `manifest_sha256`, `source_pins_sha256`, `case_approval_digest_set`, `independence_review_ref`, `cross_language_review_ref`, `coverage_review_ref`, `p0_blockers_digest`, `po_decision_ref`, `decision`, `release_revision`, `synthetic_marker`. Allowed `decision`: `PENDING`, `APPROVE_CORPUS_FOR_SEPARATELY_AUTHORIZED_USE`, `REJECT`, `DISPUTED`, `BLOCKED`. **Even `APPROVE_CORPUS...` does not authorize test execution.** Only future, distinct, independently documented PO approval can authorize either corpus issuance or test execution.

A does not enter M, F, T or BW-G2 `P`. No external real KAA/witness signature or authority is implied by a governance approval record. An approval by the fixture producer of their own output is invalid even if its SHA-256 is correct.

## 4. Acyclic exact-record identity and sealing order

The candidate immutable dependency graph is:

```text
Pinned normative sources and fixture-profile text
                ↓
Stimulus subobject S (raw bytes as hex / explicit no-input)
                ↓
Independent oracle transcript T (refers to S digest)
                ↓
Fixture F (contains S; refers to T digest)
                ↓
Independent scenario trace X (references case IDs)
                ↓
Corpus manifest M (contains sealed F/T digests and X digest)
                ↓
Reference approval A_case (refers to sealed F/T)
                ↓
Detached corpus release A_release (refers to sealed M and A_case set)
```

Technical nuance: individual approval `A_case` may follow sealing of F/T and precede or follow M, as long as it does not feed into the content hash of M. The release record follows both M and per-case approvals. X may be prepared in parallel with T/F but its **final seal** must reflect the finalized case ID mapping. None of the arrows creates a signed authority over Journal/BlobStore. 

**Proposed digest semantics** (no digests computed in Phase 3AB):

- `digest_S = SHA256(UTF8(JCS(S)))`, where S is the `stimulus` subobject, not original input JSON bytes alone.
- `digest_T = SHA256(UTF8(JCS(T_without_self_digest)))`.
- `digest_F = SHA256(UTF8(JCS(F_without_self_digest)))` after independent expected branches reference `digest_T`.
- `digest_X = SHA256(UTF8(JCS(complete_X_collection_in_declared_ID_order)))`.
- `digest_M = SHA256(UTF8(JCS(M_without_self_digest)))`, with F/T/X content digests pinned; it does not hash any future A.
- `digest_Acase` and `digest_Arelease` are computed only on detached finalized approval records; no approval digest becomes part of what it approves.

No record contains its own digest; no F digest is inside T; no future A digest is inside M; no manifest hash is inside its own approval target. Hash equality checks **bytes**, not authenticity or authority. Separate future resource policy sets hard bounds before any sealing code exists. If any source pin, raw input octet, expected stage, oracle provenance, dependency declaration or approval evidence changes, issue a **new revision**; never rewrite the sealed prior revision. Preserve withdrawal and supersession history.

## 5. Inventory, exact trace and noninflated accounting

The future corpus retains exactly the **102 Phase 3Z requirement IDs** (not 102 automatically byte-bearing goldens):

| Primary group | Planned cases | Nature |
|---|---:|---|
| V-A | 14 | V2 schema / typed field cases |
| V-B | 16 | Strict JSON/JCS/UTF-8 cases |
| V-C | 14 | Domain/frame/digest/synthetic Ed25519 |
| V-D | 16 | Typed graph/acyclic references |
| V-E | 12 | External carrier and P0-blocked cases |
| V-F | 12 | History/rollback/fork |
| V-G | 10 | Version conflict and no silent migration |
| V-H | 8 | Oracle independence / harness controls |
| **Total** | **102** | **Zero instantiated at 3AB** |

**Counters must be distinct:** `required_case_ids=102`, `fixture_records_created=0`, `golden_byte_records_approved=0`, `non_byte_cases_approved=0`, `cross_language_cases_run=0`, `conformance_tests_passed=0`. The number of future P0-blocked entries is a **classification**, not a successful proof count; do not fabricate an empirical count of constructed blocked fixtures now. All 116 earlier source-scenario IDs must have individual exact links and compatible expected diagnostics; mapping still remains work for future authorized generation, **not** an artifact made here.

**No stage-level false positives:** a negative parse case rejected for the wrong reason cannot pass because admission was denied; a carrier-blocked case cannot pass a cryptographic proof test; a harness-governance case does not manufacture bytes to complete the count. Future conformance must compare **first decisive failing stage**, issue code, exact known intermediate bytes and record identity.

## 6. Independent reference control — roles, separation and approval states

No people, keys, providers, reviewer assignments or oracle independence attestations are provisioned in this design stage.

| Role | Authority permitted in a future separately approved process | Incompatible role/self-approval |
|---|---|---|
| `SPEC_OWNER` | Maintain candidate profile and intended 3Z requirement mapping | Cannot change specs secretly to match a broken implementation |
| `FIXTURE_PRODUCER` | Propose raw S and fixture under new PO GO | Cannot approve their own reference |
| `REFERENCE_CURATOR` | Derive stage bytes from an independent declared method and retain full transcript | Cannot just copy target verifier outputs as oracle |
| `INDEPENDENT_REVIEWER` | Independently recompute/check byte transcript and lexical/stage diagnostics | Cannot serve as unchecked sole producer/curator |
| `IMPLEMENTATION_A` / `IMPLEMENTATION_B` reviewer | Disclose languages, native deps, shared backend and run future differential checks | Two wrappers of one backend do not satisfy independence |
| `DISCREPANCY_ADJUDICATOR` | Resolve mismatches with pinned source excerpts and independent byte reconstruction | Cannot adjudicate by vote/majority-only or rewriting oracle until PASS |
| `PO` | Separate approvals: profile, fixture generation, reference review/corpus release and future execution | Cannot convert synthetic reference approval to real trust admission |

**Future workflow (NOT performed):**

1. PO ratifies this narrow fixture-machine profile and resource limits; identifies responsible independent roles and collision/conflict disclosures. Ratification does **not** freeze BW-G2.
2. Under separate PO **generation GO**, producer creates S + first F draft for exact required case ID. No target verifier outputs are admitted as independent reference.
3. Curator derives T from S and source pins, preserving all intermediate octets, JCS frame digest and synthetic cryptography only if separately authorized with a reproducible public **test-only key policy**. If not derivable, branch `P0_BLOCKED`, `NOT_EVALUATED` or `NOT_APPLICABLE` explicitly.
4. Distinct reviewer independently checks T and first-reject-stage expectations, verifies toolchain and source lineage; disagreement → `DISPUTED`, no automatic repair.
5. Producer builds final F with T digest, case-kind stages, trace; seal F/T/X. Per-case A records independently bind both digests. Never mutate sealed F to add approval status.
6. M closes exactly 102 distinct required case IDs with F/T/X digests; a separate PO `A_release` decision may release an **approved synthetic reference corpus**, without changing `trusted_admission=DENIED`.
7. A later, separate PO **execution GO** may authorize offline differential conformance with at least two demonstrably independent languages. The independent reference remains authoritative pending adjudication; **agreement between targets is not proof of correct oracle**.

**Discrepancy handling:** disagreement over raw bytes, parse lexemes, JCS, domain, frame length, digest, Pure Ed25519, typed binding, version profile, reviewer conflict or resources requires a reproducible discrepancy record and explicit `DISPUTED` or `BLOCKED`. Recompute independently; version/review any design correction. Never overwrite expected bytes to force PASS. A withdrawn approval remains in the detached history; superseded records stay auditable.

**Boundary against role spoofing:** self-declared `role_ref`, an in-fixture signature, a self-signed source key, or a matching checksum is not independently authenticated approval. Actual identity evidence, separation-of-duty audit and custody remain **future process**, not granted by proposed IDL fields.

## 7. Future negative conformance matrix (specified, not tested)

| ID | Failure scenario | Expected fail-closed classification |
|---|---|---|
| `3AB-SC-01` | `M.case_entries` points to F of another vector ID | `CASE_IDENTITY_MISMATCH` |
| `3AB-SC-02` | Same case ID appears twice under different V-groups | `COVERAGE_INFLATED` |
| `3AB-SC-03` | T embeds F digest while F embeds T digest | `REFERENCE_CYCLE` |
| `3AB-SC-04` | M carries future approval digest or its own digest | `REFERENCE_CYCLE` |
| `3AB-SC-05` | `EXPECTED_BYTES` has missing or empty placeholder hex for a stage requiring bytes | `STAGE_BRANCH_INVALID` |
| `3AB-SC-06` | Parse rejection followed by a synthetic signature `EXPECTED_BYTES` | `STAGE_BRANCH_INVALID` |
| `3AB-SC-07` | Fixture counts a P0-blocked witness scenario as proof verification PASS | `P0_BOUNDARY_VIOLATION` |
| `3AB-SC-08` | R1/R5 V1 `*_digest` alias accepted as BW-G2 `*_ref` | `SCHEMA_UNSUPPORTED` |
| `3AB-SC-09` | Oracle generated from target implementation output | `VECTOR_ORACLE_NOT_INDEPENDENT` |
| `3AB-SC-10` | Producer is its own sole reference reviewer | `ROLE_SEPARATION_VIOLATION` |
| `3AB-SC-11` | Two languages share the same native JCS backend but claim independence | `INDEPENDENCE_NOT_ESTABLISHED` |
| `3AB-SC-12` | Missing one of 116 individual source-scenario trace IDs | `COVERAGE_INCOMPLETE` |
| `3AB-SC-13` | Raw hex decodes to different byte count than declared | `RAW_LENGTH_MISMATCH` |
| `3AB-SC-14` | M contains later in-place mutation of F rather than revision | `IMMUTABLE_RECORD_DRIFT` |
| `3AB-SC-15` | Attempt to use fixture approval as externally trusted root/witness | `TRUST_BOUNDARY_VIOLATION` |
| `3AB-SC-16` | Unknown fixture profile silently accepted via nearest supported revision | `UNSUPPORTED_PROFILE` |
| `3AB-SC-17` | A_case signs F revision 1 but A_release points to F revision 2 | `APPROVAL_BINDING_MISMATCH` |
| `3AB-SC-18` | Valid ASCII case claims character-vs-byte length independently proven | `COVERAGE_GAP_UNRESOLVED` (`3Z-OPEN-01`) |
| `3AB-SC-19` | Resource ceilings unratified but execution-ready flag asserted | `RESOURCE_POLICY_UNAPPROVED` |
| `3AB-SC-20` | `DENIED` used as proof that an incorrect first reject stage passed | `STAGE_RESULT_MISMATCH` |

All 20 are **future expected behaviors**, not results of executed tests or an implemented validator. The proposed issue-code names are review vocabulary, not deployed error codes.

## 8. Residual explicit decisions — **not** resolved by design acceptance

| Issue | Status after 3AB review | Required next authority/evidence |
|---|---|---|
| `3AA-OPEN-01` fixture-machine shape / stage union | **Candidate specification supplied here; NOT RATIFIED** | Dedicated PO ratification of FCP-3AB/1 + exact resource ceilings + machine-schema implementation decision |
| `3AA-OPEN-02` reproducible synthetic Ed25519 key policy | **OPEN** | Separate PO decision on publicly labeled deterministic *test-only* key policy and material disclosure; no keys now |
| `3AA-OPEN-03` curator/reviewer appointments and independence | **OPEN** | Actual independent assignments, backend disclosures, review evidence |
| `3AA-OPEN-04` 102 cases vs P0-blocked carrier accounting | **Design rule specified; not populated** | Future issued manifest/inventory and evidence of correct counts |
| `3AA-OPEN-05` exact resource limits and seal verification implementation | **OPEN** | Security review / RV-24 closure conditions before execution |
| `3AA-OPEN-06` complete 116→102 case mapping | **OPEN** | Actual row-by-row trace and independent check |
| `3Z-OPEN-01` ASCII P byte length vs char length | **OPEN** | Code-level independent review or separately authorized non-ASCII test profile; not a valid BW-G2 shortcut |
| `3Q-CR-01` Bootstrap/Genesis/Floor cycle | **DESIGN RESOLUTION PROPOSED** | Contract revision/change control, not a claim of operational proof |
| `3M-RV-18` final wire schemas and vectors | **P0 / OPEN** | Independently reviewed actual vectors, final external IDL and PO gate |
| `3M-RV-19` witness Merkle inclusion/consistency proofs | **P0 / OPEN** | Full exact crypto proof format and independent verification |
| `3M-RV-20` independent root/bootstrap | **P0 / OPEN** | External authorization, actor separation, secure provisioning |
| `3M-RV-21` trusted time and revocation freshness | **P0 / OPEN** | Independent freshness evidence |
| `3M-RV-22` immutable exact source snapshot | **P0 / OPEN** | Snapshot and TOCTOU resistance evidence |
| `3M-RV-23` independently protected durable trust floor | **P0 / OPEN** | Independent custody and continuity receipts |
| `3M-RV-24` custody, resource limits and adversarial independent security review | **P0 / OPEN** | Actual limits, threat model and independent assessment |

**13 carrier families** remain candidate/non-authoritative; a valid fixture `EXPECTED_BYTES` never implies a valid external witness, registered key, protected floor, immutable snapshot or trusted time. `BW-G2` and all proof-carrier protocols remain **NOT FROZEN**. Any real trusted use remains barred independently of this synthetic fixture-format review.

## 9. Phase 3AB design-review acceptance checklist

These are **design criteria**, not executed conformance or engineering test results:

| ID | Required document finding |
|---|---|
| `3AB-RV-01` | Explicit 3AA accepted and 3AB DESIGN-ONLY PO scope |
| `3AB-RV-02` | Exact 3AA, 3Z and upstream source pins included |
| `3AB-RV-03` | Fixture-container profile distinct from signed BW-G2 protocol |
| `3AB-RV-04` | Exact common primitives, tags and unknown-field rejection |
| `3AB-RV-05` | Manifest M has closed field inventory and no approval self-edge |
| `3AB-RV-06` | Fixture F has closed field inventory and exact case-kind union |
| `3AB-RV-07` | RAW_JSON versus NO_INPUT branch unambiguous |
| `3AB-RV-08` | All eight stage-result slots have one closed branch each |
| `3AB-RV-09` | Negative-case reachability and first-reject-stage semantics explicit |
| `3AB-RV-10` | P0_BLOCKED distinct from TEST_PASS and missing byte values |
| `3AB-RV-11` | Oracle T references stimulus digest, not circular F/M/A identity |
| `3AB-RV-12` | Source trace X covers individual 116 earlier scenario IDs |
| `3AB-RV-13` | Detached per-case and corpus approvals A tied to exact digests |
| `3AB-RV-14` | JCS container sealing and exact raw input octet retention distinguished |
| `3AB-RV-15` | Acyclic dependency/seal order and supersession defined |
| `3AB-RV-16` | 102-case group counts exact; no inflated valid-golden claim |
| `3AB-RV-17` | Independent oracle and cross-language backend restrictions explicit |
| `3AB-RV-18` | No crypto key created; future synthetic test key policy unresolved |
| `3AB-RV-19` | `3Z-OPEN-01` and external P0 blocks remain explicit |
| `3AB-RV-20` | P0 3M-RV-18…24 all remain OPEN |
| `3AB-RV-21` | No schema freeze, production changes, executable tests or vectors |
| `3AB-RV-22` | Future PO gates separately cover profile, generation, review and execution |
| `3AB-RV-23` | No implicit trust from synthetic evidence or approvals |
| `3AB-RV-24` | Proposed closure of design proliferation is not autonomous GO |

## 10. Proposed terminal design handoff — new work requires separate PO GO

**Phase 3AB is intended as the terminal review in this chain of document-only mini-phases.** After PO accepts this review, stop adding iterative fixture-schema reviews unless an actual contradictory requirement is discovered. The next meaningful work should be a single, explicitly scoped *engineering* authorization (possible label **Phase 3AC**, NOT AUTHORIZED) to ratify the narrow synthetic fixture profile/resource limits and, if authorized, build a **small pilot** with a few synthetic specimens, independent source transcripts, and test-only crypto policy. A full 102-case corpus and cross-language execution should have **separate approvals**, not be presumed from a pilot. Split the scientific agent development roadmap from production-trust P0 work under distinct gates.

Suggested future PO gates (all **NOT AUTHORIZED**):

1. `G-PROFILE`: ratify fixture-profile fields, upper resource bounds, test-key policy, named independent roles, precise source pins; still not BW-G2 freeze.
2. `G-PILOT-GENERATE`: authorize a narrow offline specimen pilot, no real authority, `UNTRUSTED` marker, `trusted_admission=DENIED` for every record.
3. `G-REFERENCE-APPROVAL`: independent reference derivation and detached case approval, auditable disagreements.
4. `G-CORPUS`: decide expansion to 102 traceable cases with an exact 116-row X map.
5. `G-EXECUTION`: separate GO for independent cross-language conformance, tests in isolated environment only.
6. `G-EXTERNAL-TRUST`: P0 closure, actual external proof infrastructure, schema freeze and subsequent production permissions are **different decisions**.

**No gate above is implicitly granted by Phase 3AB.** No simulations, oracle, external witness or production components were invoked by this review.

## 11. Status and proposed PO disposition

| Object | Phase 3AB review outcome/status |
|---|---|
| Phase 3AA | `CLOSED / ACCEPTED` by PO |
| **Phase 3AB** | **`REVIEW PREPARED / AWAITING PO ACCEPTANCE`** |
| FCP-3AB/1 fixture-machine profile | `CANDIDATE / NOT RATIFIED / NOT IMPLEMENTED` |
| Golden vectors created / reviewed | **`0 / 0`** |
| BW-G2 | `DESIGN PROPOSED / NOT FROZEN` |
| 3Q-CR-01 | `DESIGN RESOLUTION PROPOSED` |
| 3M-RV-18…24 | `P0 / OPEN` (all seven) |
| Composite Evidence Schema | `REVIEW ACCEPTED / NOT FROZEN` |
| Trust Anchor Contract v0.1 | `REVIEW ACCEPTED / NOT FROZEN` |
| Key Authorization Contract v0.1 | `REVIEW ACCEPTED / NOT FROZEN` |
| ResearchState / Experiment Selection / Research Orchestrator v1.0 | `FROZEN / UNCHANGED` |
| External trust anchors / provenance | `NOT VERIFIED` |
| Trusted admission | `DENIED` |
| Trusted implementation | `NO-GO` |
| Autonomous execution | `NO-GO` |
| Production changes | `NONE` |
| Code / key generation / executable tests / conformance | `NONE / NONE / NONE / NOT RUN` |

> **Proposed PO decision:** `Phase 3AB — RECOMMENDED FOR ACCEPTANCE` **only in `DESIGN-ONLY / REVIEW`**, as the terminal **Fixture Machine Structure & Reference Control Review**. This approval would endorse a proposed fixture machine profile and independent reference governance framework, **not** ratify executable IDL, create golden vectors, close P0, freeze BW-G2, establish trust or authorize autonomous execution. A narrowly scoped practical pilot must be separately and explicitly authorized by PO.
