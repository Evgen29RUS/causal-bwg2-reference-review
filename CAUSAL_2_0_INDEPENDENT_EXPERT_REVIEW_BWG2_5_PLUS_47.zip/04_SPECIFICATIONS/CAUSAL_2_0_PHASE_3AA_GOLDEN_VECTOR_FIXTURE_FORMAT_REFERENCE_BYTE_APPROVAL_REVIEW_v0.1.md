# CAUSAL 2.0 — Phase 3AA / Golden Vector Fixture Format & Reference Byte Approval Review v0.1

**Artifact:** `Golden Vector Fixture Format & Reference Byte Approval Review`  
**Decision class:** `DESIGN-ONLY / REVIEW`  
**Phase state:** `REVIEW PREPARED / AWAITING PO ACCEPTANCE`  
**Baseline:** Phase 3Z `CLOSED / ACCEPTED` by PO, 2026-10-30  
**Authority:** Phase 3AA `AUTHORIZED / GO`, exclusively `DESIGN-ONLY / REVIEW`  
**Execution:** NONE. **Actual golden vectors:** ZERO. **Generated keys/signatures:** ZERO. **Tests:** NOT RUN.  
**Interpretation:** candidate fixture and independent-approval procedures only; not an implemented format, machine validator, issued approval or external trust assertion.

> **Immutable scope boundary.** `BW-G2=DESIGN PROPOSED / NOT FROZEN`; `3Q-CR-01=DESIGN RESOLUTION PROPOSED`; `3M-RV-18…24=P0 / OPEN` (7/7). Composite Evidence Schema, Trust Anchor Contract v0.1 and Key Authorization Contract v0.1 remain `REVIEW ACCEPTED / NOT FROZEN`. ResearchState, Experiment Selection and Research Orchestrator v1.0 remain `FROZEN / UNCHANGED`. No changes to `C:\CAUSAL 2.0`, production code, Oracle, PPO, real keys/roots/witnesses/Journal/BlobStore, or downstream RS → ES → ORC. `external_provenance=NOT_VERIFIED`; `trusted_admission=DENIED`; `trusted_implementation=NO-GO`; `autonomous_execution=NO-GO`.

## 0. Executive design decisions for PO

| Decision | Proposed resolution | Non-authorization |
|---|---|---|
| `3AA-D-01` | Two-level, immutable **corpus manifest + individual fixture records**, plus detached approval register; never embed approval into the signed BW-G2 subject | No corpus or records populated now |
| `3AA-D-02` | Use a **closed tagged case-kind** (`BYTE_POSITIVE`, `BYTE_NEGATIVE`, `EXTERNAL_BOUNDARY`, `HARNESS_GOVERNANCE`) and **closed expected-field states** (`EXPECTED_BYTES`, `NOT_APPLICABLE`, `P0_BLOCKED`) | No fake bytes or fake crypto PASS on malformed inputs |
| `3AA-D-03` | Require an **independently established oracle**, a separate source curator and at least two demonstrably independent cross-language implementations; disagreement blocks approval | No self-generated golden values endorsed |
| `3AA-D-04` | Freeze candidate fixture *identity* only after independent review, exact source pins, manifest inventory, count/coverage and detached PO approval | This does **not** freeze BW-G2 or authorize execution |
| `3AA-D-05` | Distinguish local parse/schema/frame/signature/graph verdicts from independent external proof validation and trust admission; `DENIED` never substitutes for a correct rejection stage | No trusted admission or autonomous execution |
| `3AA-D-06` | Keep carrier-dependent scenarios `P0_BLOCKED` when full carrier IDL, proofs or independent authority are missing; their specification may be accepted but not marked executable conformance PASS | No silent fallbacks or provisional trust |

**Recommended status if accepted:** Phase 3AA `CLOSED / ACCEPTED` **in DESIGN-ONLY / REVIEW only**; every P0 remains OPEN and every existing trust gate remains NO-GO.

## 1. Controlling baseline, precedence and provenance of this review

The following are exact local reference bytes, not proof of their independent provenance. Precedence: latest express PO authority → frozen scientific v1.0 contracts → accepted non-frozen reviews → this 3AA *proposal*. A changed source pin requires an explicit review/revision; no live fallback to the “latest” document.

| Phase | Accepted source document | SHA-256 |
|---|---|---|
| 3S | `CAUSAL_2_0_PHASE_3S_BOOTSTRAP_WIRE_SCHEMA_ACYCLIC_REFERENCE_REVIEW_v0.1.md` | `8901181c49c57e79467dd0c468e70441291102e2eeffc5882651298c4803048a` |
| 3T | `CAUSAL_2_0_PHASE_3T_BOOTSTRAP_CANDIDATE_SCHEMA_CONFORMANCE_PLAN_v0.1.md` | `4ab79b5bc4c590d97daf0d9d016868eef8125047e6b527dff87090d5203f6fa0` |
| 3U | `CAUSAL_2_0_PHASE_3U_CANDIDATE_MACHINE_SCHEMA_SPECIFICATION_REVIEW_v0.1.md` | `11081301d635e2ff6cb0eabed8b6d7b1f9a43db73cf80cb5103c889ccf82aeb8` |
| 3V | `CAUSAL_2_0_PHASE_3V_SCHEMA_CONFLICT_ADJUDICATION_EXACT_CARRIER_REQUIREMENTS_REVIEW_v0.1.md` | `d6bbc763c4c5a6291f5ef8c797df07c08d33090a0a7ebac688a202bd3a87f124` |
| 3W | `CAUSAL_2_0_PHASE_3W_TYPED_REFERENCE_REVISION_EXTERNAL_CARRIER_PROFILE_REVIEW_v0.1.md` | `7fb4f71de909e886ac7675dce9fcd531edd199df61a6b7e2a00b5b43dfe7db9c` |
| 3X | `CAUSAL_2_0_PHASE_3X_BWG2_BYTE_PROFILE_DETACHED_CARRIER_PROOF_FORMAT_DECISION_REVIEW_v0.1.md` | `78f331c689df4f4ae47a8e1d1c0657c1d9abdd25465eb2c1e53ec62c44244797` |
| 3Y | `CAUSAL_2_0_PHASE_3Y_BWG2_CROSS_LANGUAGE_VECTOR_CARRIER_CLOSURE_READINESS_REVIEW_v0.1.md` | `079e4996f0a7e50a1002e4e5d2c5717e6d3a611298d664020cc7866aad6d7604` |
| **3Z** | **`CAUSAL_2_0_PHASE_3Z_BWG2_SYNTHETIC_GOLDEN_VECTOR_SPECIFICATION_v0.1.md`** | **`ec5e8a2466d1cbc99ab3897b52faa1cfb9a773b318620f2a1d4a9baecd54026a`** |

All fixture field names, enums and version identifiers below are **3AA candidate proposal**, not silently approved retroactive amendments to 3Z or earlier documents. In particular, a fixture-container schema is distinct from the **BW-G2 signed-body schema**; the fixture may carry byte strings or annotations that the signed body must never carry.

## 2. Unchanged future BW-G2 quartet and exact byte derivation

| Subject | Candidate signed-body contract | Required fields | Candidate exact signing domain |
|---|---|---:|---|
| R1V2 | `RootApprovalIntentV2` | 14 | `CAUSAL-KAA-ROOT-INTENT-v2` |
| R2V2 | `GenesisApprovalV2` | 13 | `CAUSAL-KAA-GENESIS-APPROVAL-v2` |
| R3V2 | `InitialFloorCommitmentV2` | 12 | `CAUSAL-TRUST-INITIAL-FLOOR-v2` |
| R5V2 | `BootstrapActivationCandidateV2` | 13 | `CAUSAL-KAA-BOOTSTRAP-ACTIVATION-v2` |

The **only** candidate V1→V2 signed-body key renames are R1 `previous_root_approval_intent_digest` → `previous_root_approval_intent_ref` and R5 `previous_approved_activation_digest` → `previous_approved_activation_ref`. Both are closed `GENESIS | PRIOR` typed branches; no inferred genesis, version alias or silent conversion. Use exact 3Z §2.1 field lists for all other keys. `NS4=(project_id,journal_id,source_epoch,policy_id)` must be compared with a separately supplied synthetic `expected_ns`; matching synthetic data do not establish independent authorization.

Exact candidate future computation, **not performed here**:

```text
P = UTF8(RFC8785_JCS(validated_signed_body))
L = octet_count(P)
frame = ASCII(exact_subject_domain) || 0x00 || uint64_be(L) || P
body_sha256 = lowercase_hex(SHA256(frame))
synthetic_signature = Pure_Ed25519.Sign(ephemeral_test_private_key, frame)
```

Strict UTF-8 JSON and lexical constraints, no BOM, duplicate keys, unexpected keys, floats/booleans as integers, unknown domain/contract, or non-ASCII body values in the narrow quartet. The exact frame has one NUL and eight big-endian length octets; pure Ed25519 signs the **frame**, not its digest. Cryptography here is an agreed candidate requirement, not a test result. Actual resource ceilings remain RV-24 P0.

## 3. Proposed future artifact topology and file identity

The future corpus would have **four logical layers**, none instantiated in Phase 3AA:

1. **Manifest (M):** authoritative-for-test-inventory only; source pins, candidate profile and complete unique case IDs, version, case-kind counts and immutable entry identities. No source trust grant.
2. **Fixture records (F):** exact raw-byte inputs, expected stage-by-stage result branches and optional independently approved canonical/frame/digest/signature bytes. Each has exactly one case ID.
3. **Trace and oracle evidence (T):** detached derivation worksheets, per-case cross-language outputs, dependency disclosures, discrepancy records, case-to-source-scenario mapping. Not part of BW-G2 signed bytes.
4. **Detached human approval ledger (A):** author/reviewer roles, declarations of independence, per-case decision, corpus release gate and PO authorization reference. Approval is governance metadata and **not** a cryptographic trust anchor for Journal/BlobStore.

**No reference cycle:** F→M profile identity without embedding M's ultimate self-digest; M→sealed F record hashes; A→sealed M digest; T→F identities; M must **not** hash A or its own digest. A sidecar transport checksum may hash the sealed manifest bytes. The final order and container-canonicalization rules require a future scoped decision; this candidate separation is mandatory before writing any specimens.

**Future transport allowance (candidate):** UTF-8 strict JSON fixture files, no BOM, unique keys and versioned `fixture_profile_id`; unsigned human-readable notes only in detached T. Hex holds raw bytes without decoding ambiguities: even if transport whitespace is allowed by a future manifest policy, the **decoded** `input_json_utf8_hex` is the original input octets. No paths, URLs, filenames or `latest` references may stand in for embedded exact input bytes. Manifests may enumerate logical content identifiers; actual archival layout is not an authority source.

## 4. Proposed closed manifest record (schema contract *proposal*, not populated JSON)

All fields below are **required candidate fields**, not necessarily these final wire spellings. Markers such as `REQUIRED` do not represent actual values. Unknown fields, unknown manifest revision or unapproved profile are fatal, not optional extensions.

| Candidate field | Type / semantic obligation |
|---|---|
| `manifest_profile` | Exact proposed literal `CAUSAL-BWG2-FIXTURE-MANIFEST-CANDIDATE-3AA-v1`, fixture-container version only |
| `corpus_id`, `corpus_revision` | Immutable ID and monotonically explicit revision; never an implicit latest |
| `bw_profile_id` | Exact `BW-G2` candidate, with `protocol_frozen=false` explicitly |
| `source_pins` | Closed list of source file name, source phase, SHA-256, PO acceptance record; 3Z pin mandatory |
| `schema_profile_digest` | Candidate quartet specification identity; no invented final schema SHA until approved |
| `fixture_format_profile_digest` | Future independent seal of this fixture format's approved version |
| `corpus_kind`, `synthetic_marker` | Exact `SYNTHETIC_TEST_ONLY`, `UNTRUSTED` |
| `expected_external_provenance`, `expected_trusted_admission` | `NOT_VERIFIED`, `DENIED`; immutable allowed expectations |
| `case_id_order` | Exact deterministic ordering of unique case IDs, not filesystem iteration |
| `case_entries` | Exact case ID, one primary group, kind, F record digest, current approval state and no duplicate IDs |
| `group_expected_counts` | Fixed Phase 3Z allocation `14/16/14/16/12/12/10/8`; additional cases need explicit revision |
| `source_scenario_trace_digest` | Binding to complete 116-source-scenario T mapping when later produced |
| `oracle_method_id`, `independence_policy_id` | Identifies a separately reviewed oracle methodology and implementation-independence criteria |
| `resource_policy_id` | Approved limits required before later generation/execution; currently RV-24 OPEN |
| `predecessor` | Closed `FIRST_CORPUS` vs `SUPERSEDES` branch; if supersedes, sealed prior manifest digest and reason |
| `approval_ledger_ref` | **Detached pointer only**, not a signed-body or self-referential hash; approval must verify which exact sealed manifest was reviewed |
| `manifest_status` | `DRAFT`, `UNDER_REVIEW`, `APPROVED_FOR_FUTURE_USE`, `SUPERSEDED`, `REJECTED`; no implicit promotion |

**Critical clarification:** a future `APPROVED_FOR_FUTURE_USE` manifest means only an *independently curated synthetic test corpus*. It does not mean `SCHEMA FROZEN`, that any real issuer is authorized, or that execution is approved. PO may accept this Phase 3AA document without approving any manifest, fixture or producer.

## 5. Per-fixture format: four closed variants and stage-value branches

### 5.1. Identity and immutable basis (common envelope)

Every future fixture F SHALL carry the following candidate semantic fields:

| Group | Mandatory candidate fields | Rule |
|---|---|---|
| Identity | `fixture_profile_id`, `vector_id`, `primary_group`, `case_kind`, `requirement_ref`, `revision` | `vector_id` must exactly match a planned 3Z ID or an explicitly authorized extension; one and only one primary V-A…V-H group |
| Scope | `subject_contract`, `subject_domain`, `expected_ns`, `source_pins_digest` | For quartet the contract/domain are allowlisted; `expected_ns` is an **independent synthetic fixture parameter**, not established by subject itself |
| Raw transport | `input_json_utf8_hex`, `input_byte_count`, `input_origin` **or** explicit tagged no-input branch for pure governance cases | Exact original octets (including malformed transport) without normalization; no invented empty string |
| Oracle lineage | `reference_method_id`, `reference_case_identity`, `oracle_state`, `independence_record_ref` | Target implementation's output is not its own oracle; `oracle_state` must not falsely say approved |
| Expected local outcome | `expected_first_reject_stage`, `expected_issue_codes`, `expected_stage_results` | Stage-specific positive/negative/not-evaluated; global `DENIED` is not sufficient |
| Safety | `synthetic_marker=UNTRUSTED`, `expected_external_provenance=NOT_VERIFIED`, `expected_trusted_admission=DENIED`, `expected_downstream_invoked=false` | Cannot be overridden by a fixture or expected signature |
| Trace | `source_scenario_refs`, `cross_case_dependencies` | No vacuous source coverage; dependency graph must remain acyclic and type/domain bound |

An external/proof-blocked or harness-governance case must use its **explicit closed no-input branch** rather than fabricate a valid quartet subject. All references within a specimen are expected *synthetic* identities, not real issuer attestations.

### 5.2. Case-kind branch: permitted evidence and blocking results

| `case_kind` | Required input / expectations | Forbidden interpretation |
|---|---|---|
| `BYTE_POSITIVE` | Strict valid quartet raw input; independently calculated P, frame, digest and, where cryptographic case, ephemeral synthetic signature/public key; graph expectation if relevant | Never external provenance or admission GRANT |
| `BYTE_NEGATIVE` | Exact malformed or deliberately mismatched input; declared *first decisive rejection stage* and relevant expected earlier-stage outputs only | Must not fabricate later canonical/frame/signature bytes after parse rejection |
| `EXTERNAL_BOUNDARY` | Exact external carrier requirement ID, expected P0 blocker and explicit `P0_BLOCKED` states; if it also includes valid local bytes they are a separate nested local facet | Must not invent Merkle proofs/real receipts, call blocked carrier "valid", or count proof verification PASS |
| `HARNESS_GOVERNANCE` | Exact case stimulus regarding independence, provenance, duplicate IDs, isolation or review process; explicit diagnostic expectation | No pretending a harness policy check is a cryptographic golden byte vector |

This **typed distinction matters for the 102-case plan**: not every future case will have a meaningful `signing_frame_hex` or even a subject JSON, especially V-E and V-H. A future corpus may separately count **total case records**, **independently approved byte-bearing records**, **blocked carrier cases**, and **executed tests**. It must not report “102 valid golden byte vectors” when the inventory contains governance and P0-blocked cases.

### 5.3. Mandatory closed stage-result union (fixture-container proposal)

Each stage slot (parse, schema, canonical, frame, digest, synthetic signature, typed linkage, external proof) has exactly one branch:

| State | Required accompanying data | Allowed when |
|---|---|---|
| `EXPECTED_BYTES` | Exact lowercase hex bytes, decoded octet length, expected algorithm/domain and independent `oracle_record_ref` | Stage was reached, operation is well-defined, bytes independently approved |
| `EXPECTED_VERDICT` | Exact verdict code, stage ID, expected diagnostic, `oracle_record_ref` | Stage is meaningful but has no byte result (e.g., parser reject) |
| `NOT_APPLICABLE` | Exact predecessor rejection stage and reason code; **no bytes** | Earlier failure prevents reaching this stage, or case has no such operation |
| `NOT_EVALUATED` | Stage that stopped evaluation, exact reason | Stage would exist on a valid branch but was not run after earlier reject |
| `P0_BLOCKED` | Exact 3M-RV P0 ID, unavailable external profile/version, missing evidence class | External proof cannot be checked under accepted candidate schema |

`null`, empty hex, an omitted stage field, synthetic `proof_verified=true`, and a fake signature/digest to fill a negative case are prohibited substitutions. Unknown branch types, mixed branch payloads or an after-failure `EXPECTED_BYTES` are **fixture invalid**. A global denied gate is **orthogonal** to the expected local stage result. The exact binding of stage slots to these branches must be explicitly versioned in the future machine IDL; no machine parser exists now.

### 5.4. Byte-bearing fields when the stage is reachable

For a locally valid case, the future record MUST contain independently approved exact expectations for:

- Raw: `input_json_utf8_hex`, `input_byte_count`, independent interpretation of original lexemes.
- Canonical: `canonical_payload_utf8_hex`, `canonical_payload_length_decimal` for `P`; field order and transport whitespace changes may be equivalent only after strict parsing.
- Frame: `domain_ascii_hex`, `separator_hex=00`, `uint64_be_length_hex` (8 octets), `signing_frame_hex`, `hash_input_kind=FRAME`.
- Digest: `body_sha256` (64 lowercase hexadecimal characters of **full frame**), with algorithm identity `SHA256`.
- Synthetic crypto (where applicable): `test_algorithm=pure-Ed25519`, `test_public_key_hex` (32 octets), `test_signature_hex` (64 octets), `test_key_provenance=EPHEMERAL_SYNTHETIC`, plus a **reviewed key-material publication policy**; no real signer identity.
- Graph: `typed_ref_branch`, `expected_target_contract`, `expected_target_domain`, `expected_target_version`, `edge_identity_digests`, expected lineage/rank; exact independent expected namespace.

These are **future field obligations, not populated values**. Synthetic test private keys are not part of a delivered corpus. Reproducible signature vector strategy (fixed publicly labeled synthetic fixture key vs nondeterministic ephemeral test-only case) remains a **separate future PO-approved crypto-fixture decision**; it cannot be settled by inventing key material in Phase 3AA.

## 6. Future 102-case inventory and 116-source trace gate

The 3Z inventory is **required unchanged** until a separately authorized revision. It contains *requirements*, not instantiated cases:

| Primary group | Cases planned | Scope |
|---|---:|---|
| V-A | 14 | Quartet structures and exact field types |
| V-B | 16 | JSON/JCS/UTF-8 and canonicalization |
| V-C | 14 | Signing frame, hash, synthetic signature |
| V-D | 16 | Typed predecessor references, exact cross-object identities |
| V-E | 12 | External carrier and P0-blocked boundaries |
| V-F | 12 | Key/floor/witness history, rollback and fork |
| V-G | 10 | V1/V2 conflicts and no silent fallback |
| V-H | 8 | Oracle independence, limits and isolation |
| **TOTAL** | **102** | **0 actual vectors** |

A future corpus must enumerate every `3Z-V-A-01…14`, `3Z-V-B-01…16`, `3Z-V-C-01…14`, `3Z-V-D-01…16`, `3Z-V-E-01…12`, `3Z-V-F-01…12`, `3Z-V-G-01…10`, `3Z-V-H-01…08` exactly once (or explicitly approved new IDs). One specimen is not duplicated to inflate coverage. `P` (locally possible) is not authority; `N` cases may legitimately terminate before byte derivation. Source trace MUST map all **116** scenarios `3S-SC-01…30`, `3V-SC-01…18`, `3W-SC-01…20`, `3X-SC-01…24`, `3Y-SC-01…24` individually to case IDs, with reasoned exact stimulus/expected-diagnostic compatibility. Range-only trace or group-level claims are incomplete.

**Coverage accounting policy (candidate):** counters for specified IDs, authored fixture files, independently approved byte expectations, approved non-byte scenarios, blocked P0 cases, executable tests, and passed tests are all **separate**. In Phase 3AA they are, respectively, **102 required IDs / 0 authored / 0 independently approved / 0 approved scenarios / 0 tested / 0 passed**; P0 blocked requirements remain as planned, not as a measurement of produced files.

## 7. Independent reference byte approval procedure (future; none carried out)

### 7.1. Separation of responsibility and authority

| Role (no individual named or appointed) | Future permissible duty | Must not do |
|---|---|---|
| `SPEC_OWNER` | Maintains reviewed candidate protocol text and case intent, proposes clarification | Quietly edit expected bytes to fit implementation |
| `FIXTURE_PRODUCER` | Later, under separate PO GO, creates raw specimen inputs and records their deterministic origin | Self-approve reference bytes |
| `REFERENCE_CURATOR` | Independently derives P/frame/digest and permitted synthetic signature expectations with declared method, toolchain and independent source | Reuse target implementation output as ground truth |
| `INDEPENDENT_REVIEWER` | Independently re-derives or checks full octet transcript, lexical rejection, domain/typed reference; signs off explicit decision | Be the same person/unchecked toolchain as producer and sole curator |
| `IMPLEMENTATION_A_REVIEW`, `IMPLEMENTATION_B_REVIEW` | Compare at least two independently implemented languages with disclosed native dependencies and versions | Rebrand wrappers to same canonicalizer as independent |
| `DISCREPANCY_ADJUDICATOR` | Reviews disagreements using pinned protocol/spec, source transcript, independent recomputation; rules accept/reject or re-specify | Resolve by majority vote or whichever implementation was first |
| `PO` | Authorizes next phase and accepts documentation, future corpus issuance and test execution via **separate gates** | Convert synthetic review into trust authority or production GO |

A single actor may propose documentation, but **may not independently create and approve the same reference**. Actual assignment, dual control and conflicts of interest are **not established** here. Independent reviewer and oracle origin cannot be named as `VERIFIED` before their separate records exist.

### 7.2. Required lifecycle of one future reference record

1. **PROPOSED:** `FIXTURE_PRODUCER` registers unique `vector_id`, exact source pins, revision, case kind, raw octets or explicit no-input case, declared earliest reject stage and provenance. No expected byte fields may claim approval.
2. **SPEC-CHECKED:** `SPEC_OWNER` verifies contract/domain/NS4, exact 3Z case intent, field count, candidate V2 generation and resource preconditions. Open ambiguity → `BLOCKED_SPEC`, no downstream issuance.
3. **REFERENCE-DERIVED:** `REFERENCE_CURATOR` independently derives P, length, frame, digest and synthetic signature where applicable, or `NOT_APPLICABLE/P0_BLOCKED` for unreachable/external cases. Retain exact toolchain, intermediate octets and derivation steps in detached T.
4. **INDEPENDENTLY-REVIEWED:** distinct reviewer recomputes stage outcomes and **octet-for-octet** expected transcript using an independent method; checks signature semantics and typed graph from separate expected scope. Toolchain common ancestry disclosed. Failed independent comparison → `DISPUTED`.
5. **DIFFERENTIAL-READY:** when separately authorized, at least **two independent implementations in different languages** are selected and their dependency graphs reviewed; these are prospective cross-checks and do not replace the reference curator. Not performed in this phase.
6. **DISCREPANCY RESOLVED:** no unaddressed disagreements about raw/canonical/frame/hash/signature or first failing stage; a resolution must identify source-document line and fix version. No target-output overwrite.
7. **REFERENCE-APPROVED:** detached sign-off binds exact F bytes, oracle transcript and independently approved source pins and is recorded in ledger A. This is **corpus reference approval only**; no real trust authorization.
8. **CORPUS SEALED / PO GATE:** after all required cases and full trace, seal M + F + T and let PO decide release/use. Any changes invalidate the earlier approval and require new revision and review. Separate PO GO is needed before **any execution**.

**Dissensus rule:** if two independent languages agree with each other but disagree with reference bytes, the case remains `DISPUTED` until independent adjudication—agreement is not an automatic license to rewrite the oracle. If the curated oracle agrees with implementation A but not B, conformance also remains blocked. If the specification is ambiguous, amend its *candidate revision* via PO review; never patch fixture bytes to force a PASS.

### 7.3. Approval record (detached, proposed semantic fields)

`approval_record_id`, `vector_id`, `fixture_digest`, `reference_transcript_digest`, `manifest_profile_digest`, `source_pins_digest`, `oracle_method_id`, `fixture_producer_role_ref`, `reference_curator_role_ref`, `independent_reviewer_role_ref`, `conflict_disclosure`, `independent_derivation_evidence_ref`, `byte_comparison_status`, `expected_failure_stage_check`, `cross_language_dependency_review`, `discrepancy_refs`, `decision`, `decision_scope=SYNTHETIC_REFERENCE_ONLY`, `PO_release_gate_ref`. Decision is one of `APPROVE_REFERENCE`, `REJECT_REFERENCE`, `DISPUTED`, `BLOCKED_BY_P0`, `PENDING`.

An approval must refer to exactly one sealed fixture digest and a specific profile revision. A role label, a signature on a carrier or an SHA-256 file by itself is not evidence of an independent human review. No real approvals are being issued.

### 7.4. Corpus-change and revocation rules

- Replacing any raw input octet, expected byte, case kind, issue code, trace mapping, dependency disclosure or source pin must create a **new immutable fixture/corpus revision**, not edit an approved golden in place.
- Superseded corpus and discrepancy history remain visible. A withdrawn approval is not a cryptographic revocation of real trust keys, and does not change historic Journal trust floor.
- Unknown corpus profile, missing source pin, changed domain, missing reviewer, shared backend, incomplete stage branch, or future-approval claim without immutable digest all block reference release.
- No import from the Phase 3H V1 synthetic verifier, unapproved BW-G2 migration or carrier `proof_verified` flag can bypass this procedure.

## 8. Explicit handling of P0 and unresolved design questions

| Item | Condition / necessary future PO decision | Phase 3AA treatment |
|---|---|---|
| `3Z-OPEN-01` | ASCII-only valid quartet cannot distinguish byte-count versus character-count algorithms using only valid vectors | **OPEN**; independent implementation review or separately authorized non-ASCII extension profile; no Unicode valid-vector shortcut |
| `3AA-OPEN-01` | Final **fixture container** machine IDL, field sizes, typed negative and blocked branches, canonicalization and seal transcript | CANDIDATE ONLY; requires separate scoped spec revision |
| `3AA-OPEN-02` | Reproducible synthetic Ed25519 fixture key-material policy; safe public test-only release vs ephemeral-only in-memory tests | BLOCKED UNTIL NEW PO AUTHORITY; no key now |
| `3AA-OPEN-03` | Appointment and demonstrable independence of curator/reviewer, code/language/backend provenance, evidence retention | PROCESS NOT EXECUTED |
| `3AA-OPEN-04` | Scope/executable handling of blocked external-carrier cases within 102 plan | MUST STAY `P0_BLOCKED`, not counted as crypto proof PASS |
| `3AA-OPEN-05` | Exact corpus sealing canonicalization and file/manifest byte limits; avoid self-hash graph | PENDING resource/IDL decision |
| `3AA-OPEN-06` | Actual algorithm for source-to-vector 116-row mapping and a complete approved trace | PLANNED / NOT CREATED |
| `3M-RV-18` | Final wire schema/transport, test vectors | P0 / OPEN |
| `3M-RV-19` | Witness inclusion+consistency proof crypto and byte transcripts | P0 / OPEN |
| `3M-RV-20` | External bootstrap/authority and role authenticity | P0 / OPEN |
| `3M-RV-21` | Independent time and revocation freshness | P0 / OPEN |
| `3M-RV-22` | Immutable exact source snapshot / TOCTOU | P0 / OPEN |
| `3M-RV-23` | Independently protected floor and durable receipt proof | P0 / OPEN |
| `3M-RV-24` | Resource limits, custody, adversarial independent review | P0 / OPEN |

**Boundaries for all 13 external carriers:** root authority, initial custody, activation approval, subsequent floor and custody, witness A, witness B, KAA, trusted time, immutable source snapshot, signer issuance, Anchor carrier and Composite bundle remain **candidate semantic profiles**. Their issuer, cryptographic transcript, historical proof and full machine encoding cannot be established by a golden fixture alone. Local `EXPECTED_BYTES` never implies external `PROVENANCE_VERIFIED`.

## 9. Future failure/adversarial review scenarios — specified only (`3AA-SC-01…22`)

| ID | Hypothetical failure | Expected review response |
|---|---|---|
| 01 | Target implementation computes its own reference P/frame/hash | `VECTOR_ORACLE_NOT_INDEPENDENT` |
| 02 | Producer approves own expected outputs | `ROLE_SEPARATION_VIOLATION` |
| 03 | Two languages call the same native canonicalizer | `INDEPENDENCE_NOT_ESTABLISHED` |
| 04 | Manifest contains 102 labels but a duplicate F specimen counted twice | `COVERAGE_INFLATED` |
| 05 | V-E blocked case presented as signed valid local golden byte vector | `CASE_KIND_MISMATCH` |
| 06 | Parse-invalid input carries signature `EXPECTED_BYTES` after parse reject | `STAGE_BRANCH_INVALID` |
| 07 | Expected bytes replaced by `null`, `""` or empty hex as N/A | `STAGE_BRANCH_INVALID` |
| 08 | Shared canonicalizer versions are omitted from independence report | `ORACLE_PROVENANCE_INCOMPLETE` |
| 09 | Manifest omits source 3Z pin or imports a modified source | `REFERENCE_DRIFT` |
| 10 | P/frame agree but `body_sha256` computed over P only | `BODY_DIGEST_MISMATCH` |
| 11 | Pure Ed25519 signs digest or uses ph/ctx instead of frame | `SIGNATURE_PROFILE_UNSUPPORTED` |
| 12 | Unknown V1 body accepted as R1V2 by matching field aliases | `SCHEMA_UNSUPPORTED` |
| 13 | Source-scenario mapping lists range names but not 116 individual IDs | `COVERAGE_INCOMPLETE` |
| 14 | Fixture asserted canonical P based only on semantic JSON text | `CANONICAL_BYTES_UNAPPROVED` |
| 15 | Independent A/B disagreement auto-resolved by majority vote | `DISPUTE_UNRESOLVED` |
| 16 | Corpus changed after reviewer approval without new digest | `APPROVAL_BINDING_MISMATCH` |
| 17 | Wrong subject domain hidden behind correct transport wrapper SHA | `SIGNING_FRAME_MISMATCH` |
| 18 | Fixture uses synthetic approver label as real KAA authorization | `EXTERNAL_PROVENANCE_NOT_VERIFIED` |
| 19 | Case marked PASS because final admission is DENIED despite wrong reject stage | `VERDICT_BLOCKED` |
| 20 | Future test runner invoked under mere Phase 3AA document acceptance | `PO_EXECUTION_NOT_AUTHORIZED` |
| 21 | Valid ASCII case claimed to distinguish UTF-8 byte length vs character count | `COVERAGE_OVERCLAIM_3Z_OPEN_01` |
| 22 | Manifest checksum points to approval record that points back into manifest hash | `APPROVAL_REFERENCE_CYCLE` |

All diagnostics above are **review-level expected classifications**, not results emitted by existing code. No vectors or tests executed.

## 10. Review checklist (`3AA-RV-01…32`) and acceptance evidence

| ID | Phase 3AA review criterion | Expected disposition |
|---|---|---|
| 01 | Explicit PO 3AA DESIGN-ONLY authority | Documented |
| 02 | 3Z CLOSED/ACCEPTED, 0 golden vectors unchanged | Documented |
| 03 | Original 8 source-document SHA-256 pins match | Verified locally |
| 04 | BW-G2 remains NOT FROZEN, all P0 OPEN | Preserved |
| 05 | R1/R2/R3/R5 exact domains and field counts | Preserved |
| 06 | Only two prior-ref field renames, no silent alias | Preserved |
| 07 | Manifest versus fixture versus oracle transcript versus approval records separated | Specified |
| 08 | Independent expected NS4, no self-provisioned authority | Specified |
| 09 | Raw transport bytes distinguished from canonical P | Specified |
| 10 | Frame uses one NUL, 8 BE octets, SHA256(frame) | Specified |
| 11 | Pure Ed25519 signs frame, not digest | Specified |
| 12 | Closed four case kinds and stage-result union | Specified |
| 13 | Parse-invalid fields cannot contain fabricated later-stage crypto PASS | Specified |
| 14 | `NOT_APPLICABLE`, `NOT_EVALUATED`, `P0_BLOCKED` distinct | Specified |
| 15 | No null/empty-string/omission as error-state silent fallback | Specified |
| 16 | Case uniqueness 14+16+14+16+12+12+10+8 = 102 | Specified |
| 17 | Mapping all 116 earlier source scenarios individually required | Specified |
| 18 | Golden byte approval is separate from actual test execution | Specified |
| 19 | Producer, curator, reviewer and PO roles non-self-approving | Specified |
| 20 | Independent cross-language implementation requirement and shared library disclosure | Specified |
| 21 | Divergent expected bytes block corpus release | Specified |
| 22 | All expected bytes trace to independent derivation evidence | Specified |
| 23 | Detached approval binds exact immutable fixture identity | Specified |
| 24 | No manifest/approval self-reference cycle | Specified |
| 25 | Supersession is new revision, no in-place overwrites | Specified |
| 26 | All 13 carrier families retained P0-blocked where appropriate | Specified |
| 27 | `3Z-OPEN-01` remains open, no false length coverage | Specified |
| 28 | Crypto fixture test-key policy explicitly deferred | Specified |
| 29 | No actual source I/O, keys, vectors, verifier or tests | Confirmed for this artifact |
| 30 | `trusted_admission=DENIED` and downstream invocation prohibited | Preserved |
| 31 | Future PO gates for fixture generation, execution and schema freeze distinct | Specified |
| 32 | All 22 3AA design scenarios identified but not executed | Specified |

**Meaning of Phase 3AA acceptance:** a future-fixture and independent-reference-approval *plan* has been reviewed. No machine schema has been ratified; no exact golden expected bytes have been derived; no independent reviewers, reference approvals or cross-language results exist by virtue of this acceptance.

## 11. Explicit future PO-gated steps (not authorized by Phase 3AA)

| Gate | Proposed future action | Current authority |
|---|---|---|
| `3AA-G0` | PO accepts/refuses this requirements-only review | AWAITING PO |
| `3AA-G1` | Freeze a **narrow synthetic fixture-format test profile** with types, resources, branches, revision pins (not BW-G2 schema freeze) | NOT AUTHORIZED |
| `3AA-G2` | Independently appoint producer/curator/reviewer; approve derivation, independence and synthetic key-material policies | NOT AUTHORIZED |
| `3AA-G3` | **Separate PO GO:** create raw fixture records and independently curate expected byte transcripts, solely offline/synthetic | NOT AUTHORIZED |
| `3AA-G4` | Conduct independent per-case approvals and bind immutable manifest, full 102-case inventory and 116-case trace; retain P0 blocked classifications | NOT DONE |
| `3AA-G5` | **Separate PO GO:** run independent cross-language conformance in isolation; audit discrepancies and negative-stage results | NOT AUTHORIZED |
| `3AA-G6` | Any final wire schema freeze or real external trust verification | SEPARATE P0/PO GO; NO-GO |
| `3AA-G7` | Trusted admission/production integration/autonomous execution | NO-GO |

**Proposed minimal next step after 3AA acceptance:** a **design-only fixture IDL & independent oracle governance decision** that chooses and reconciles remaining fixture-record branch/wire ambiguity, without actually creating golden vectors. This is only a recommendation; no next phase is authorized.

## 12. Final status ledger and proposed PO decision

| Object | Status |
|---|---|
| Phase 3Z | `CLOSED / ACCEPTED` (PO) |
| **Phase 3AA** | **`REVIEW PREPARED / AWAITING PO ACCEPTANCE`** |
| BW-G2 | `DESIGN PROPOSED / NOT FROZEN` |
| 3Q-CR-01 | `DESIGN RESOLUTION PROPOSED` |
| 3M-RV-18…24 | `P0 / OPEN` (7/7) |
| Composite Evidence Schema | `REVIEW ACCEPTED / NOT FROZEN` |
| Trust Anchor Contract v0.1 | `REVIEW ACCEPTED / NOT FROZEN` |
| Key Authorization Contract v0.1 | `REVIEW ACCEPTED / NOT FROZEN` |
| ResearchState / ES / ORC v1.0 | `FROZEN / UNCHANGED` |
| Generated golden vectors, keys, signatures, executable verifier, conformance tests | `0 / 0 / 0 / NONE / NOT RUN` |
| External trust anchors / provenance | `NOT VERIFIED` |
| Trusted admission | `DENIED` |
| Trusted implementation | `NO-GO` |
| Autonomous execution | `NO-GO` |
| Production changes | `NONE` |

> **Proposed PO decision:** Phase 3AA is **RECOMMENDED FOR ACCEPTANCE solely within DESIGN-ONLY / REVIEW**. The candidate manifest/fixture/stage-result branches and independent reference-byte approval workflow are review decisions, not executable schemas or approved golden vectors. No P0 is closed, no schema is frozen, and no keys, vectors or tests are created. A future phase requires explicit separate PO authorization for any fixture generation, independent computation, conformance execution or trust-system operation.
