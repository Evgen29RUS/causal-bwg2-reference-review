# CAUSAL 2.0 — Phase 3X / BW-G2 Normative Byte Profile & Detached Carrier Proof-Format Decision Review

**Document ID:** `CAUSAL-PHASE-3X-BWG2-BYTES-CARRIER-DECISIONS`  
**Revision:** `v0.1 — DESIGN-ONLY / REVIEW CANDIDATE / NOT FROZEN`  
**Date:** `2026-10-30`  
**PO authority:** `Phase 3W — CLOSED / ACCEPTED`; `Phase 3X — AUTHORIZED / GO`  
**Deliverable:** byte-level and independent-proof-format **decision review**, not registered wire protocol, executable schema, verifier, test vectors, key ceremony or external-trust activation.

> **Mandatory safety boundary.** `BW-G2 = DESIGN PROPOSED / NOT FROZEN`; `3Q-CR-01 = DESIGN RESOLUTION PROPOSED`; `3M-RV-18…24 = P0 / OPEN` (seven of seven). Composite Evidence Schema, Trust Anchor Contract v0.1, Key Authorization Contract v0.1 = `REVIEW ACCEPTED / NOT FROZEN`. ResearchState, Experiment Selection and Research Orchestrator v1.0 = `FROZEN / UNCHANGED`. No changes in `C:\CAUSAL 2.0`; no production code, Oracle, PPO, real key/root/witness/provider, real Journal/BlobStore, network, cryptographic execution, executable validator or autonomous execution. `external_provenance = NOT_VERIFIED`; `trusted_admission = DENIED`; `trusted_implementation = NO-GO`; `autonomous_execution = NO-GO`. Acceptance of this **review** is not acceptance of the proposed normative wire profile.

## 0. Executive disposition and deliberately separated claims

1. **Choose a single *candidate* signed-byte profile for the four BW-G2 bodies R1V2/R2V2/R3V2/R5V2**: restricted-I-JSON object grammar, RFC 8785/JCS canonical UTF-8 bytes on that restricted domain, exact domain-separated framing `ASCII(D)||0x00||uint64_be(len(P))||P`, SHA-256 over the framed bytes, and the *candidate* pure Ed25519 signature over those same framed bytes. Explicitly prohibit Ed25519ph, signing only the digest, generic JSON serialization, field aliases and implicit V1→V2 conversion. This is a **design choice** requiring exact conformance vectors and PO change-control before any registered implementation.
2. **Retain BW-G2 four-body revision as a unit**. R1V2 and R5V2 use the renamed, closed `GENESIS|PRIOR` typed reference fields; R2V2/R3V2 use their respective distinct V2 contract and domain tags. Preserve cardinalities 14/13/12/13 and independently expected flat NS4. Do not edit original 3U/3W files or old 3G `AnchorPayloadV1`.
3. **Select typed *candidate proof forms*, one per external purpose**. Distinguish signed *subject* bytes from separately authenticated *carriers*, Merkle inclusion and consistency objects, durable floor receipts, external governance approvals, key-state/revocation attestations, freshness, snapshot evidence and external signer issuance. The outer role/binding fields can be selected now; the actual independent issuers, custody and some nested proof bytes remain `P0-BLOCKED`.
4. **Pick an append-only witness proof family for further normative work:** SHA-256 Merkle tree hashing with RFC 9162 §2.1 structural algorithms (leaf `SHA256(0x00||entry_bytes)`, node `SHA256(0x01||left||right)`), two separately authenticated witnesses and independently pinned heads. The *CAUSAL-specific leaf encoding, signed head carrier, full inclusion/consistency wire encoding and independent authority/cosigning* are still candidate requirements, not verified or fully frozen implementations. Do not assert that a generic array of hashes proves witness history.
5. **Preserve fail-closed behavior**: an unknown generation, unsupported proof profile, missing external prerequisite, mismatched exact bytes, stale registry/floor, unsigned alleged authority or unavailable independent witness yields `UNVERIFIED / DENIED` or structural rejection. Never map these to scientific `ES.ABSTAIN` or `ORC.SAFE_HALT`.

**Proposed PO decision:** accept this *decision dossier* at `DESIGN-ONLY / REVIEW` only; do not issue `3W-CR-01…10`, do not close `3M-RV-18…24`, do not freeze `BW-G2` or authorize the next stage by implication.

## 1. Controlling sources, precedence, and source-vs-new-decision register

The following existing project documents are used as **accepted design baselines, NOT frozen wire standards**:

| Basis | Material constraints used | What Phase 3X may add, without editing it |
|---|---|---|
| Phase 3G v0.1 | `AnchorPayloadV1`, exact prefix/closure, source signer vs independent trust | No modification to its v1 signing bytes or verification meaning |
| Phase 3I / 3J | Key delegation, revocation, rotations, 2-of-2 witness, independent trust floor | Detached carrier fields and future proof profile decision candidates |
| Phase 3M | Composite evidence, `3M-RV-18…24`, no silent fallback | Explicit anti-mismatch and freeze prerequisites |
| Phase 3P / 3Q / 3R | Authority separation, cycle `3Q-CR-01`, a DAG for initial bootstrap | Byte identities matching that DAG, without granting authority |
| Phase 3S / 3T | R0…R8 and 30 proposed adversarial cases; plan for future byte vectors | Exact list of required vectors and non-executable test expectations |
| Phase 3U | 14/13/12/13 proposed signed-body field sets, JSON type proposals | Candidate canonical subset and precise framing |
| Phase 3V | 16 typed-ref / carrier conflict dispositions; 18 new cases | Typed proof forms with no undocumented aliases |
| **Phase 3W** | `BW-G2` R1V2/R2V2/R3V2/R5V2, proposed v2 signing domains, 13 carrier families, 20 more cases | One candidate byte-profile choice and distinct carrier proof-format decisions |

Precedence: **explicit current PO authorization → frozen scientific contracts → accepted/not-frozen design baselines → Phase 3X candidates**. Nothing in this document upgrades a proposed `P1` carrier profile or `BW-G2` into a recognized wire generation. Local SHA-256 is document identity only and not an independent provenance anchor.

**External technical references (design guidance, not operational dependencies):** RFC 8785 (JSON Canonicalization Scheme), RFC 8032 (pure Ed25519), RFC 9162 §2.1 (Merkle tree and inclusion/consistency proofs). References: https://www.rfc-editor.org/rfc/rfc8785 , https://www.rfc-editor.org/rfc/rfc8032 , https://www.rfc-editor.org/rfc/rfc9162 . RFC 9162's CT transport structures are **not** adopted merely by borrowing its tree construction: CAUSAL leaf/checkpoint wire types require separate decisions.

## 2. Decision 3X-BY-01: exact BW-G2 signed-body catalog and binding

### 2.1. Fixed *candidate* subject identity

| Rank / identifier | Contract literal (one exact string) | Framing/signing domain `D` | Key count | Prerequisites in signed body |
|---|---|---|---:|---|
| R1V2 | `RootApprovalIntentV2` | `CAUSAL-KAA-ROOT-INTENT-v2` | 14 | Independently authorized R0; earlier R1V2 typed predecessor or explicit authorized genesis |
| R2V2 | `GenesisApprovalV2` | `CAUSAL-KAA-GENESIS-APPROVAL-v2` | 13 | R1V2 digest in R1V2 domain; same R0 policy |
| R3V2 | `InitialFloorCommitmentV2` | `CAUSAL-TRUST-INITIAL-FLOOR-v2` | 12 | R1V2, R2V2 body digests; initial floor predecessor |
| R5V2 | `BootstrapActivationCandidateV2` | `CAUSAL-KAA-BOOTSTRAP-ACTIVATION-v2` | 13 | R1V2/R2V2/R3V2 body digests; earlier R5V2 typed predecessor or explicit authorized genesis |

R0 is an **external authority precondition**, not a signed child of R1. R4 is a detached receipt about R3V2 and an out-of-band prerequisite for approval of R5V2. R6 is detached approval of sealed R5V2. R7 is a *subsequent floor subject*, **not a receipt**, and R8 is its detached receipt. Neither R4 nor R6 nor R8 may be inserted into an earlier signed body's digest set. Cross-generation predecessor links are `DENIED` absent a separately authorized transition protocol (not specified here).

### 2.2. Exact reference unions and digest discipline

The following tagged JSON object shapes are **candidate exact nested sets**, with no other keys, nulls or defaults:

```text
GENESIS = { "kind": "GENESIS", "genesis_rule_id": LOCAL_ID }
PRIOR   = { "kind": "PRIOR", "target_contract": CONTRACT_TAG,
            "target_body_sha256": DIGEST32_HEX, "target_version": VERSION_POS }
```

- R1V2: `previous_root_approval_intent_ref` is `GENESIS|PRIOR`; for `PRIOR` the target contract MUST equal `RootApprovalIntentV2` and `target_version` MUST equal the independently accepted prior `intent_version`.
- R5V2: `previous_approved_activation_ref` is `GENESIS|PRIOR`; for `PRIOR` target contract MUST equal `BootstrapActivationCandidateV2` and `target_version` MUST equal the independently accepted earlier `bootstrap_version` **and approval history**.
- `GENESIS` here denotes **the predecessor of that particular lineage**, not the R2 `GenesisApprovalV2` subject. It requires an externally approved rule in exact NS4. Missing predecessor, an empty Journal or zero sequence never implies genesis.
- Plain `*_digest` fields are exactly 64 lowercase hex characters, but their **type** also includes the expected subject contract, signing domain, rank and independently accepted version from the schema edge registry. A matching 64-hex string by itself cannot authorize an edge.
- R2V2 `initial_source_state_commitment` is the disjoint `EXACT_SOURCE_GENESIS` (`source_state_sha256`) or `AUTHORIZED_ABSENT_SOURCE` (`absent_source_rule_id`) branch from 3U. No `null` and no inference from an empty source.
- R3V2 `initial_predecessor` keeps the `EXPLICIT_GENESIS_REF` shape; later floor predecessor semantics remain in the separate, unfinished R7 profile.

### 2.3. Flat scope / type constraints carried forward as proposals

`NS4 = (project_id, journal_id, source_epoch, policy_id)` is **four flat top-level keys** in every BW-G2 subject. Strings for `project_id`, `journal_id`, `policy_id` and `LOCAL_ID` follow the candidate restricted ASCII grammar `^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$` (1–128 ASCII bytes), exact-case equality. `source_epoch`, version/counter fields are JSON integers (not bool, float, exponent, negative zero), with a proposed safe range `1..9007199254740991` for positive values and `0..9007199254740991` for contextually authorized nonnegative counters. Hex digests are `[0-9a-f]{64}`. No path normalization, case folding or Unicode normalization.

These bounds originate in Phase 3U's **proposed profile** and remain subject to RV-18/RV-24; claiming them as already frozen would be incorrect. The independently accepted `expected_NS4` is supplied out-of-band, not inferred from signed bodies or supplied carrier claims. Cross-object exact equality is mandatory.

## 3. Decision 3X-BY-02: candidate byte encoding and canonicalization

### 3.1. Strict input grammar before canonicalization

For each R1V2/R2V2/R3V2/R5V2 body, this review selects **restricted I-JSON + RFC 8785/JCS canonicalization** on an intentionally narrowed input domain:

1. A signed body is one JSON object with the exact, exhaustive fields of its V2 contract from 3W + the unchanged 3U field lists. `contract` is part of the signed bytes and must equal the exact V2 literal. No optional fields, `null`, booleans, arrays, floats, NaN/Infinity, unknown fields or duplicate keys at any depth. The only nested objects allowed are the closed tagged unions described in §2.2. (Future approved carriers may have arrays; they do not inherit this quartet-only restriction.)
2. All signed-body property names and permitted values are **ASCII strings with field-specific grammar** (IDs, fixed literals and lowercase digests). No Unicode or escape-based substitute for a field-restricted literal. *This ASCII restriction is a CAUSAL design choice*, not a general property of JCS.
3. Incoming wire JSON for these bodies is strict UTF-8 without BOM, with all object keys unique. A JSON lexer must reject lexical numeric forms not in the restricted integer grammar (`-0`, `1.0`, `1e0`, `01`, etc.) **before** losing their original spelling. Whitespace and incoming property order in an unsigned transport wrapper need not equal canonical bytes, provided strict parsing and complete re-encoding are enforced. Signed-body byte fields (if present in a carrier) must exactly match the re-encoded canonical output; no silently normalized substitutions.
4. Canonical signed-body JSON bytes `P` are JCS serialization per RFC 8785: deterministic unescaped property-name sorting by UTF-16 code units, deterministic string escaping, compact separators, no insignificant whitespace, UTF-8 bytes. For the ASCII-only field names of BW-G2, UTF-16 lexical order coincides with ASCII code-unit order. No trailing newline or BOM. Never use locale-dependent key comparison or an unspecified host JSON serializer.
5. JCS does not perform Unicode normalization; this profile rejects Unicode rather than guessing normalization. All signature and digest operations use the **same** `P` calculated from strict parsed subject data. Reject any ambiguity between transport bytes and canonical payload bytes.

**Cross-language caveat:** JCS is a specified standard, but CAUSAL's additional constraints (ASCII-only payload, integer-lexeme prefilter, exact field tables, nested unions) are *proposed protocol rules*. They still need an independently implemented differential corpus and approved protocol version. No such corpus was generated in Phase 3X.

### 3.2. Exact candidate framing, digest and signature input

For approved candidate domain ASCII literal `D` and canonical UTF-8 payload bytes `P`:

```text
L := byte_length(P)                                  # NOT character length
frame(D,P) := ASCII(D) || 0x00 || uint64_be(L) || P  # unsigned 8-byte BE length
body_sha256(D,P) := lowercase_hex(SHA256(frame(D,P)))
signature_candidate(D,P) := Ed25519.Sign(SK, frame(D,P))
verification_candidate(D,P) := Ed25519.Verify(PK, frame(D,P), signature)
```

`D` is an exact allowlisted ASCII domain from §2.1, **without** an appended terminator inside `D`; framing adds exactly one NUL, then exactly eight length bytes in network byte order, then `P`. No second length prefix, no newline, no lowercase alias. The length is bounded by separately approved resource policy (RV-24); `uint64_be` is a framing format, not permission for unbounded allocation. A `body_sha256` is the SHA-256 of the **complete frame**, *not* of `P` alone, not a source blob hash, not transport JSON hash and not the Ed25519 prehash of `P`.

The **selected candidate algorithm** for these G2 body signatures is *pure Ed25519* over the exact frame (RFC 8032). `Ed25519ph`, `Ed25519ctx`, hashing-before-signing, alternative curves and generic “EdDSA” negotiation are rejected in this candidate. Signature bytes are 64 octets; public-key bytes 32 octets; encoding in a future carrier is proposed as exact lowercase hex of bytes, but public key authorization still requires independent root/KAA state. No private key, public key, signature or test vector is created by Phase 3X.

### 3.3. Identity propagation and body/carrier separation

A future proof carrier may transport the signed subject bytes and external proof fields; it MUST NOT be included in the subject `P`. A candidate `signed_body_identity` triple is `(subject_contract, subject_domain, subject_body_sha256)` plus independently expected NS4 and approved lineage version. Recompute the entire identity, never accept a claimed digest as the sole evidence.

| Input / output | Proposed equality invariant | Denial example |
|---|---|---|
| R2V2 `root_approval_intent_digest` | recomputed R1V2 `body_sha256` | V1 R1 hash supplied in place of V2 |
| R3V2 `root_approval_intent_digest` and `genesis_approval_digest` | same R1V2/R2V2 identities as accepted R2 | equal-looking digest with wrong domain |
| R5V2 three body digest fields | recomputed R1V2/R2V2/R3V2 | R4 custody-receipt digest substituted |
| R4 proof subject | exact finalized R3V2 body digest | claimed prefix hash substituted |
| R6 proof subject | exact finalized R5V2 body digest; R4 gate accepted separately | R5 containing later R6 digest (cycle) |
| R7 predecessor | explicit accepted R3V2 or earlier R7, with independent floor history | source-only reset of floor lineage |
| R8 proof subject | exact sealed R7 body digest | R8 digest inside signed R7 |
| Anchor v1 carrier | exact *unchanged* 3G `AnchorPayloadV1` domain/bytes | 3H synthetic wrapper promoted to authority |

All byte identities change if a contract literal, field name, nested reference branch, signing domain or canonicalization choice changes. Consequently V1 and BW-G2 cannot be mix-and-matched by “same meaning” interpretation.

## 4. Decision 3X-PF-01: detached carrier design semantics

**Subject:** an already sealed signed body whose `subject_body_sha256` is computed under its exact domain. **Carrier:** an external, purpose-specific authenticated assertion/proof about that subject. **Registry/policy:** independently pinned authority context not supplied by that same carrier. **Proof material:** verifiable bytes or separately authenticated content-addressed bytes, not a URL, filename, mock flag, caller-provided public key or JSON boolean.

### 4.1. Candidate common carrier identity header (review-only)

The following is a proposed **minimum header**, not yet an exhaustive IDL or independently authenticated object:

| Proposed key | Candidate type / exact semantic binding |
|---|---|
| `carrier_contract` | exact role-specific literal (not `generic_carrier`) |
| `carrier_profile` | one selected Phase 3W P1 profile, exact literal |
| `carrier_version` | positive integer, independently accepted per-profile generation |
| `project_id`, `journal_id`, `source_epoch`, `policy_id` | NS4, matched to independently expected scope; R0 has a separately explicit approved scope-set rule |
| `subject_contract`, `subject_domain`, `subject_body_sha256` | exact sealed subject; R0 uses separate independent policy identity and cannot bootstrap by self-reference |
| `issuer_identity_ref` | prior externally provisioned issuer identity, not a key included in this carrier |
| `authority_state_ref` | separately authenticated issuance-time delegation/revocation snapshot |
| `proof_material_ref` | closed proof material descriptor; authenticated bytes, bounded length and algorithm/profile |
| `history_binding_ref` | externally accepted predecessor/checkpoint/floor identity |
| `purpose` | one fixed, non-interchangeable role literal |

Further candidate proof descriptors MUST distinguish **exact inline bytes** from an independently authenticated content-addressed retrieval; no scheme may silently dereference a pathname or remote URL. Proof bytes in any carrier MUST be bound to `carrier_profile`, issuer, exact subject and relevant prior protected history. The general carrier header alone does **not** prove any of these assertions. Whether proof bytes/signatures are nested or detached, their algorithms, wire encodings and secure retrieval channels remain separate approvals under RV-18/19/20/23/24.

### 4.2. No self-authenticating carrier

A carrier's signature, if present, is evidence only *relative to* its independently authorized issuer and approved signing domain. It cannot register its own root key, override a previously accepted floor, authorize a signer's role, establish a timestamp oracle or attest immutable capture merely by claiming it. Authentication policy must precede the carrier; any missing external foundation returns `UNVERIFIED / DENIED`. Disjoint proof purposes are non-substitutable even if the same SHA-256 value appears in two records.

## 5. Decisions 3X-PF-02…14: exact candidate proof *forms* by external role

These profiles are selected **for design review**. The field sets below are candidate **minimum typed subrecords** describing what a future closed carrier must transport. They are not complete signatures, RFC 9162 CT messages, HSM receipts or validated provider protocols. A future normative IDL must set exact field order/keys, type/size limits, proof byte representation, signer authorization and transcript bytes for each profile.

| Role / 3W profile ID | Selected candidate proof form: required typed subrecord contents | Mandatory external verification; blocking P0 |
|---|---|---|
| **R0** `CAUSAL-EXT-ROOT-POLICY-P1` | `root_policy_subject_digest`, `policy_version`, `approved_scope_set_digest`, `roles_policy_digest`, `quorum_policy_digest`, `recovery_policy_digest`, `bootstrap_approval_ref`, `previous_approved_root_policy_ref` | Independent PO/governance issuance history and actual custody; `RV-20/24` |
| **R4** `CAUSAL-EXT-INITIAL-FLOOR-RECEIPT-P1` | `sealed_r3_body_sha256`, `custody_object_id`, `custody_counter`, `durable_commitment_digest`, `previous_custody_state_ref`, `custodian_assertion_ref` | Independently durable monotonic receipt and authentic custodian; never inside R3; `RV-21/23/24` |
| **R6** `CAUSAL-EXT-ACTIVATION-APPROVAL-P1` | `sealed_r5_body_sha256`, `approval_policy_ref`, `approval_quorum_evidence_ref`, `previous_approved_activation_ref`, `prerequisite_r4_receipt_ref`, `approval_decision=APPROVED` | Approved signers and quorum, authenticated R4 gate and prior state; never inserted in R5; `RV-20/24` |
| **R7** `CAUSAL-EXT-SUBSEQUENT-FLOOR-P1` | `floor_version`, `predecessor_floor_ref`, `source_anchor_body_sha256`, `trust_state_digest`, `witness_checkpoint_a_digest`, `witness_checkpoint_b_digest`, `floor_policy_digest` | Closed separately signed R7 *subject* and independently accepted floor monotonicity; no R8 reference; `RV-18/19/23` |
| **R8** `CAUSAL-EXT-FLOOR-RECEIPT-P1` | `sealed_r7_body_sha256`, `custody_object_id`, `custody_counter`, `previous_custody_state_ref`, `durable_commitment_digest`, `custodian_assertion_ref` | Authenticated independent protected storage and anti-rollback proof; `RV-23/24` |
| **Witness A** `CAUSAL-EXT-WITNESS-A-P1` | `witness_identity_ref`, `log_id`, `tree_size`, `tree_root_sha256`, `signed_head_ref`, `leaf_index`, `leaf_entry_digest`, `inclusion_path`, `prior_tree_size`, `prior_tree_root_sha256`, `consistency_path` | Verified signed head, inclusion and append-only consistency, independently provisioned root; `RV-19/20` |
| **Witness B** `CAUSAL-EXT-WITNESS-B-P1` | Same typed fields as A, separately authenticated issuer and log; exact same bound subject/history | 2-of-2 independent A/B; a duplicated root/operator is not independent; `RV-19/20` |
| **KAA** `CAUSAL-EXT-KAA-STATE-P1` | `registry_version`, `registry_digest`, `delegation_state_digest`, `revocation_state_digest`, `effective_counter_range`, `preceding_registry_digest`, `issued_under_policy_ref` | Single authenticated coherent historical registry/rotation/revocation state; `RV-18/20/21` |
| **Time** `CAUSAL-EXT-TIME-P1` | `subject_body_sha256`, `time_assertion_id`, `time_interval_start_utc`, `time_interval_end_utc`, `time_authority_ref`, `issued_under_policy_ref` | Independently authenticated bounded currentness interval and revocation SLA; `issued_at_utc` is not proof; `RV-21` |
| **Snapshot** `CAUSAL-EXT-SOURCE-SNAPSHOT-P1` | `source_ns`, `journal_prefix_byte_length`, `journal_prefix_sha256`, `prefix_event_hash`, `blob_closure_digest`, `capture_id`, `capture_boundary_ref`, `isolation_attestation_ref` | Verified immutable capture / TOCTOU isolation, exact bytes and closure; `RV-22/24` |
| **Signer issuance** `CAUSAL-EXT-SIGNER-ISSUANCE-P1` | `anchor_body_sha256`, `source_capture_id`, `signer_key_identity_ref`, `authorized_counter`, `authorized_policy_ref`, `source_inspection_evidence_ref` | Independent signer authorization + actual inspection at issuance; `RV-20/22/24` |
| **Anchor** `CAUSAL-EXT-ANCHOR-CARRIER-P1` | `anchor_payload_contract=AnchorPayloadV1`, `anchor_domain=CAUSAL-RS-SOURCE-ANCHOR-v1`, `anchor_body_sha256`, `signature_bytes_ref`, `signer_key_identity_ref`, `issuance_evidence_ref` | Preserve 3G bytes and check authorized signer separately; Phase 3H wrapper is not carrier; `RV-18/20` |
| **Composite** `CAUSAL-EXT-COMPOSITE-BUNDLE-P1` | `bundle_manifest_digest`, exact member `profile_id + subject_digest + material_digest + version`, `expected_ns_ref`, `accepted_external_state_ref`, `bundle_completeness_policy_ref` | Closed membership; reject omitted/replaced profiles, no claimant-set defaults; `RV-18/24` |

**Important R7 note:** R7's row is a *candidate signed subject* profile, included in this 13-family list because Phase 3W lists it there; R7 must **not** be reclassified as a detached custody receipt. R8 remains the detached receipt. All fields in this table are requirements candidates, not machine-ready schemas and not source of new authority.

## 6. Decision 3X-PF-15: witness Merkle proof-format candidate

### 6.1. What is selected, and what is not

For a future append-only witness log, select the **RFC 9162 §2.1 SHA-256 Merkle-tree construction** as a candidate for review:

```text
MTH(empty)        = SHA256(empty_bytes)
leaf_hash(e)      = SHA256(0x00 || e)
node_hash(l, r)   = SHA256(0x01 || l || r)
root(n entries)   = RFC9162_MTH(ordered_entries[0:n])
```

Each witness must supply **both** a proof that the exact bound entry appears at index `i < tree_size` under an authenticated tree head and a consistency proof from an independently stored earlier head to the new head (except for an expressly authorized first-head bootstrap branch). The proof paths are ordered arrays of 32-byte hashes, not arbitrary unordered sets; inclusion verification uses the leaf index/tree size; consistency verification binds both old and new sizes and hashes. Zero-length, equal-size and first-head cases must be explicitly specified; no empty proof accepted as evidence by default. A pair of independently signed heads alone is not append-only proof.

**CAUSAL-specific `entry_bytes` candidate (not an already registered CT leaf):** `frame("CAUSAL-WITNESS-EVIDENCE-LEAF-v1", JCS(ClosedWitnessLeafBody))`, with a future closed leaf body binding `NS4`, exact source-prefix commitment, exact AnchorPayloadV1 signed-body digest, one authenticated KAA trust-state digest, witness purpose, and cross-checked R3/R7 floor identity. This leaf body is **not yet a closed field set**: its definitive ordering, allowed repeated entries, status-dependent floor field (initial vs subsequent), signature-head encoding and issuer policy must be resolved under RV-18/19/20. An actual RFC 9162 `TransItem` / CT tree head cannot be substituted for this proposed CAUSAL form by declaration.

### 6.2. Candidate inclusion/consistency carrier fields and rejection semantics

| Subproof | Required exact candidate items | Reject if |
|---|---|---|
| Inclusion | `leaf_entry_digest`, `leaf_index`, `tree_size`, `root_hash`, ordered `audit_path`, `witness_log_id` | `leaf_index >= tree_size`, invalid path length/order, digest mismatch, unsigned head |
| Consistency | `old_tree_size`, `old_root_hash`, `new_tree_size`, `new_root_hash`, ordered `consistency_path`, `witness_log_id` | rollback (`new_size < old_size`), conflicting equal-size head, proof missing, unanchored prior head |
| Signed head | `witness_log_id`, `tree_size`, `root_hash`, `head_sequence`, `head_signing_domain`, `issuer_key_ref`, signed transcript | claimed issuer is not externally authorized, stale head, wrong domain, fork/equivocation |
| Cross-witness acceptance | independently pinned A root + B root, independently confirmed head/history and **same bound source/anchor/trust-state** | same root/operator, one missing witness, A/B subject mismatch, no gossip/anti-equivocation policy |

This is **an explicit format-selection decision candidate** at the level of proof family and required fields, not a complete executable Merkle proof verifier. In particular the future RFC-compatible exact leaf transcript, signed head bytes, algorithm identifiers, path bounds, first-head acceptance, gossip/equivocation strategy and vector corpus are `P0 / OPEN`. Witness independence requires governance and operational evidence; an algorithm cannot provide it by itself. No witness checks are executed in Phase 3X.

## 7. Decision 3X-PF-16: independent floor, approval and authority proof boundaries

- **R0 root policy**: must be obtained from an independently accepted PO/governance provisioning record preceding R1V2; bootstrap proof must bind policy version, exact scope set, quorum/recovery and separately retained authority state. A self-signed R0 inside a submitted evidence bundle is **not** a trust anchor.
- **R4 custody**: independently durable, monotonic proof about sealed R3V2 (R3 contains no R4 link); signing a receipt is not proof of protected storage. Need later provider- and retention-specific evidence.
- **R6 approval**: a detached quorum decision about exact R5V2 and already verified R4 state; its `APPROVED` claim is not enough without independently authorized roles and revocation check. R5's `activation_state=CANDIDATE` never self-activates.
- **R7**: subsequent signed floor, distinct from initial R3V2; must use accepted predecessor and be independently guarded against rollback/fork. R7 cannot include R8's future custody digest.
- **R8 custody**: independently durable proof about already sealed R7; append-only custody state and external trust floor history must be authenticated separately.
- **Recovery / rotation**: no implicit reset of source epoch, signer counters, custody counters or registry versions. Recovery requires separately authorized ceremony and explicit lineage bridge; no silent “start from genesis again”.

## 8. Verification and denial order (future design; *not implemented*)

| Gate | Future verification requirement | Fail-closed diagnostic family |
|---|---|---|
| G0 | Current phase/PO permission check; Phase 3X always terminates as design review | `TRUSTED_ADMISSION_NOT_AUTHORIZED` |
| G1 | Canonical grammar, complete field sets, exact V2 generation/profile support, resource limits | `SCHEMA_UNSUPPORTED`, `CANONICAL_BYTES_INVALID` |
| G2 | Independent expected NS4 and R0 policy/bootstrap; role and domain allowlist | `ROOT_NOT_PROVISIONED`, `SCOPE_MISMATCH` |
| G3 | Recompute 4 frame digests; typed-edge registry and acyclic predecessor graph | `BODY_DIGEST_MISMATCH`, `CROSS_CONTRACT_BINDING_MISMATCH` |
| G4 | Independent source capture and unchanged 3G anchor exact prefix/blob links | `SOURCE_SNAPSHOT_UNVERIFIED`, `SOURCE_LINKAGE_UNVERIFIED` |
| G5 | KAA key authorization, continuous rotation/revocation, approved historical state | `KEY_AUTHORIZATION_UNKNOWN`, `TRUST_STATE_INCOHERENT` |
| G6 | Independently authenticated witness A/B, both inclusion+consistency proofs and anti-equivocation | `PROOF_PROFILE_UNSUPPORTED`, `WITNESS_DISAGREEMENT` |
| G7 | R4/R6 approval/custody, R7/R8 as applicable, and independent protected floor | `FLOOR_NOT_INDEPENDENT`, `BOOTSTRAP_ACTIVATION_NOT_AUTHORIZED` |
| G8 | Independently authenticated freshness, revocation recency and platform security | `FRESHNESS_UNKNOWN`, `SECURITY_GATE_OPEN` |
| G9 | Separate future admission/PO authorization; **never in Phase 3X** | `UNVERIFIED / DENIED` |

A structural fail at any gate must not be coerced into a successful later gate. A locally well-formed body can have a valid signature under a synthetic key and still have `key_authorization=NOT_VERIFIED`. Statuses for the trust layer are **not** `ES.ABSTAIN` or `ORC.SAFE_HALT`.

## 9. Future byte-vector manifest and differential verification obligations

**No vectors are generated here.** A separately authorized conformance phase must create a versioned manifest where each case records:

| Vector attribute | Required evidence |
|---|---|
| `vector_id`, `subject_contract`, `revision`, `domain` | Exact G2/R1…R5 case identity |
| `payload_json_utf8_hex`, `canonical_payload_utf8_hex` | Exact raw semantic input and canonical bytes; no skipped bytes |
| `payload_byte_length_uint64_be_hex` | Eight-byte big-endian length of canonical payload |
| `signing_frame_hex`, `body_sha256` | Domain/NUL/length/payload framing and SHA-256 |
| `test_public_key_hex`, `test_signature_hex` | **Synthetic only**, approved generation source in isolated future harness |
| `edge_expected_contract_domain`, `expected_ns` | Typed signed-body linkage and independent scope expectation |
| `expected_schema`, `expected_signature`, `expected_trust` | Separate judgments; *expected trust always `DENIED` for synthetic cases* |
| `expected_reason_codes`, `test_profile_hash` | Reproducible negative test and immutable test profile identity |
| `independent_implementation_ids` | Cross-language/cross-library agreement, not just one encoder replaying itself |

A future corpus must include: R1/R2/R3/R5 nominal byte identities; both `GENESIS` and `PRIOR` branches; wrong-version/wrong-domain hash substitution; JSON key reordering; whitespace in incoming transport; duplicate key at top/nested level; escaped vs literal ASCII allowed-field values; BOM; Unicode and non-ASCII payload rejection; leading-zero/noncanonical numeric lexeme, bool-for-int, exponent/floating point, length off-by-one, reordered domain NUL, alternative Ed25519 variants, signature of digest instead of frame, hash-only predecessor, null predecessor, alias to legacy V1 and unknown carrier. Inclusion/consistency vectors must include one-leaf, non-power-of-two tree, append-only extension, wrong index, wrong left/right path, equal-size different root, fork, rollback, mismatched witness roots, missing independent prior floor and mock proof bytes.

**Traceability obligations preserved:** `3S-SC-01…30`, `3V-SC-01…18`, `3W-SC-01…20`. These are **designed future cases**, not 68 tests run in Phase 3X. A later review must map each ID to named byte/proof vector IDs and identify blocked cases, never silently mark an unimplemented proof as passing. Phase 3T's targeted coverage is planning guidance, not proof of completion.

## 10. Conflict and decision ledger

| Decision ID | Selected review option | Explicitly rejected shortcut | Pending change control |
|---|---|---|---|
| `3X-BY-01` | BW-G2 quartet + strict v2 domains | mutate V1 in place | `3W-CR-01` |
| `3X-BY-02` | restricted I-JSON + RFC8785/JCS subset | unspecified JSON serializer | `3W-CR-01/02` |
| `3X-BY-03` | `ASCII(D)||00||u64be(L)||P` | hash payload only / length chars | `3W-CR-01` |
| `3X-BY-04` | pure Ed25519 over frame | Ed25519ph or digest signing | `3W-CR-01/09` |
| `3X-BY-05` | typed `GENESIS|PRIOR` refs | hash-only predecessor or implicit genesis | `3W-CR-02` |
| `3X-PF-01` | purpose-specific detached carrier header | generic signed JSON as all evidence | `3W-CR-03…09` |
| `3X-PF-02` | R0 pre-provisioned authority proof | source-contained root | `3W-CR-03` |
| `3X-PF-03` | R4 detached monotonic receipt | receipt inside R3 | `3W-CR-04` |
| `3X-PF-04` | R6 detached quorum approval | R5 self-approval | `3W-CR-05` |
| `3X-PF-05` | R7 floor subject + R8 distinct receipt | R7/R8 digest cycle | `3W-CR-06/04` |
| `3X-PF-06` | RFC9162 §2.1 tree math candidate | arbitrary witness hash-array | `3W-CR-07` |
| `3X-PF-07` | distinct witness A/B roots & histories | two mock instances same operator | `3W-CR-07` |
| `3X-PF-08` | one coherent authenticated KAA state | mixed registry snapshots | `3W-CR-08` |
| `3X-PF-09` | externally authenticated time interval | source `issued_at_utc` as proof | `3W-CR-08` |
| `3X-PF-10` | isolated exact source capture | local hash = immutable snapshot | `3W-CR-08` |
| `3X-PF-11` | independent signer issuance subject | valid signature = authorized issuance | `3W-CR-08` |
| `3X-PF-12` | separate unchanged AnchorPayloadV1 carrier | 3H test wrapper as provider | `3W-CR-09` |
| `3X-PF-13` | closed composite membership | optional carrier omission | `3W-CR-09/10` |
| `3X-PF-14` | independent proof material and history | URI/self-declared key as authority | `3W-CR-10` |
| `3X-PF-15` | ordered Merkle inclusion+consistency forms | heads-only / no consistency | `3W-CR-07` |
| `3X-PF-16` | independent floor and root governance | source-provided floor policy | `3W-CR-03/04/05` |

**These IDs are Phase 3X design records only**. They do not constitute issued PO change records, registered suites, proof verification or closure of contractual conflicts. The exact byte/conformance requirements above are stronger proposals than Phase 3W's open canonicalization choice, not silent amendments to 3W itself.

## 11. New negative scenarios — `3X-SC-01…24` (SPECIFIED / NEVER EXECUTED)

| ID | Future attempt / mismatch | Required fail-closed diagnostic |
|---|---|---|
| 01 | V1 `contract` accepted with a V2 domain | `SCHEMA_UNSUPPORTED` |
| 02 | Signed body byte length counts Unicode characters instead of UTF-8 octets | `CANONICAL_BYTES_INVALID` |
| 03 | Wrong position/number of NUL/length bytes in domain framing | `SIGNING_FRAME_MISMATCH` |
| 04 | SHA256(payload) substituted for SHA256(frame) | `BODY_DIGEST_MISMATCH` |
| 05 | Ed25519 signs 32-byte hash, not frame | `SIGNATURE_INVALID` |
| 06 | Ed25519ph, Ed25519ctx or algorithm negotiation in BW-G2 | `SIGNATURE_PROFILE_UNSUPPORTED` |
| 07 | Duplicate JSON property nested inside typed `PRIOR` | `CANONICAL_BYTES_INVALID` |
| 08 | Invalid numeric lexical form parsed and silently normalized | `CANONICAL_BYTES_INVALID` |
| 09 | Unicode/escape alias accepted for ASCII-only field | `SCHEMA_UNSUPPORTED` |
| 10 | `GENESIS` inferred from missing earlier subject | `GENESIS_NOT_AUTHORIZED` |
| 11 | `PRIOR` targets different version, lineage or NS4 | `TYPED_REFERENCE_MISMATCH` |
| 12 | R3V2 digest edge points to R2V1 hash | `CROSS_CONTRACT_BINDING_MISMATCH` |
| 13 | R4 receipt digest inserted in signed R3V2 | `CYCLIC_REFERENCE_REJECTED` |
| 14 | R6 approval inserted in R5V2 signed body | `CYCLIC_REFERENCE_REJECTED` |
| 15 | Witness inclusion path wrong index/order | `WITNESS_INCLUSION_INVALID` |
| 16 | Valid signed witness head, no consistency proof from protected prior head | `WITNESS_HISTORY_UNKNOWN` |
| 17 | Two witnesses share independent-looking identifiers but same root/operator | `WITNESS_INDEPENDENCE_UNVERIFIED` |
| 18 | R8 receipt claims durability but no protected custodian state | `FLOOR_NOT_INDEPENDENT` |
| 19 | Authorized signer claimed using carrier-contained key only | `KEY_AUTHORIZATION_UNKNOWN` |
| 20 | Valid local source hash under concurrent source mutation | `SOURCE_SNAPSHOT_UNVERIFIED` |
| 21 | Signed `issued_at_utc` masquerades as external currentness | `FRESHNESS_UNKNOWN` |
| 22 | Composite omits R4 or replaces B with A | `COMPOSITE_PROOF_INCOMPLETE` |
| 23 | P1 profile chosen as a fallback from unknown profile | `PROOF_PROFILE_UNSUPPORTED` |
| 24 | All mock bytes internally consistent; no external anchors or PO trusted GO | `TRUSTED_ADMISSION_NOT_AUTHORIZED` |

Future *nominal* byte vectors must also carry `synthetic_marker=UNTRUSTED` and `trusted_admission=DENIED`, even where syntax, digests and synthetic signatures are correct. No tests run in Phase 3X.

## 12. Open P0 gates, real-world blockers and conditions before freeze

| P0 | What Phase 3X determines **on paper** | What remains OPEN before PO can close it |
|---|---|---|
| `3M-RV-18` | Chosen candidate JCS subset, v2 domains/frame, named proof-role headers | Full closed normative IDL for **all** carriers/R7, byte-for-byte interoperable vectors, distinct signed transport wrappers, explicit approved PO schema change records |
| `3M-RV-19` | Candidate SHA-256 Merkle family, typed inclusion/consistency fields | Exact CAUSAL witness leaf/head transcripts and real proofs, approved A/B root independence, verified vectors and anti-equivocation operation |
| `3M-RV-20` | Candidate external R0/R6 governance forms, independent issuer binding | Authenticated actual bootstrap, independent role/quorum validation, recovery, key-provisioning evidence |
| `3M-RV-21` | Bounded independent timestamp receipt fields and revocation check gate | Approved trusted time service, current authenticated revocation source, freshness SLA/limits and evidence |
| `3M-RV-22` | Snapshot proof binds exact prefix/closure/capture ID | Independently verified immutable capture mechanism for actual platform, TOCTOU/alias/symlink/collision/threat review |
| `3M-RV-23` | R4/R8 independent receipt fields and history binding | Independent durable monotonic store, true rollback/fork resistance, custody evidence and failure recovery |
| `3M-RV-24` | Rejection/resource obligations and explicit role separation | Finite bound schedule for every bytes/depth/proof path/count/algorithm, actual key custody plan, red-team/adversarial review and PO signoff |

`3Q-CR-01` remains `DESIGN RESOLUTION PROPOSED`: the DAG avoids *proposed* cyclic signed digest references but is not an approved final machine protocol. A schema freeze requires separate scope, full wire validation/cryptographic evidence and explicit PO freeze decision. Even freeze would not imply trusted admission or autonomous execution.

## 13. Phase 3X review checklist `3X-RV-01…30`

| ID | Review obligation (DESIGN-ONLY, not executed tests) |
|---|---|
| 01 | Current PO authorization and no-execution boundary stated |
| 02 | 3W status accepted, BW-G2 still only proposed |
| 03 | All seven `3M-RV-18…24` explicitly remain P0 |
| 04 | R1V2/R2V2/R3V2/R5V2 exact literal/domain map preserved |
| 05 | Key counts 14/13/12/13 and 3U unmodified fields preserved |
| 06 | NS4 expected out-of-band, no acceptance from submitted claims |
| 07 | Typed `GENESIS|PRIOR` closed branches and role-specific target lineage |
| 08 | Plain digest fields bound to expected contract/domain/rank |
| 09 | Restricted JSON input and duplicate-key/bool/float/lexical-number rules |
| 10 | RFC8785/JCS subset and exact UTF-8 ASCII-only value constraints |
| 11 | Exact domain NUL/uint64 length frame with byte length |
| 12 | Digest of frame, not payload or transport |
| 13 | Pure Ed25519 frame signing as candidate, no prehash |
| 14 | 3G AnchorPayloadV1 and synthetic 3H wrapper not reinterpreted |
| 15 | R0 separate independent authority bootstrap boundary |
| 16 | R4/R6/R8 detached, no receipt/approval cycles |
| 17 | R7 signed floor subject distinguished from R8 carrier |
| 18 | All 13 profile families covered by typed proof-format decisions |
| 19 | Witness A/B proof family distinguishes inclusion and consistency |
| 20 | Witness independence and signed head external authorization unresolved |
| 21 | KAA snapshot, revocation/rotation and floor monotonic history obligations |
| 22 | Freshness, source capture and signer issuance remain separate proof domains |
| 23 | Composite completeness and no generic carrier substitution |
| 24 | Exact future byte-vector manifest defined, no generated vectors claimed |
| 25 | Prior 3S/3V/3W scenarios carried forward as unexecuted obligations |
| 26 | All `3X-SC-01…24` defined as future negative cases |
| 27 | No silent fallback, no cross-version implicit migration, no TOFU |
| 28 | P0 closure vs schema freeze vs trusted implementation are separate PO gates |
| 29 | Production code, RS/ES/ORC, keys, providers, source and autonomous execution untouched |
| 30 | Result is review dossier only, not code/test/certified external proof |

These are design-review acceptance **requirements**, not 30 performed tests. No independent cross-language implementation, cryptographic tests, signed fixtures, real proof material or security audit is delivered.

## 14. Next safe step (recommendation only; NOT AUTHORIZED)

**Suggested Phase 3Y — BW-G2 Cross-Language Vector & Carrier Closure Readiness Review**, initially `DESIGN-ONLY / REVIEW`: decide the remaining exact JSON lexical rules, full R7 and external carrier IDL, CAUSAL witness leaf/head byte transcripts, initial/empty proof semantics and test-vector provenance; create a review matrix for a **separately authorized later** in-memory conformance implementation. Do not authorize algorithms or providers by inference, and do not begin code, key generation, source adapters or real external integration.

## 15. Status ledger and proposed PO decision text

| Object | Current / proposed status after preparation of this artifact |
|---|---|
| Phase 3W | `CLOSED / ACCEPTED` (PO) |
| **Phase 3X** | **`REVIEW PREPARED / AWAITING PO ACCEPTANCE`** |
| BW-G2 | `DESIGN PROPOSED / NOT REGISTERED / NOT FROZEN` |
| 3X byte profile and detached carrier choices | `DESIGN PROPOSED / NOT REGISTERED / NOT FROZEN` |
| `3Q-CR-01` | `DESIGN RESOLUTION PROPOSED` |
| `3M-RV-18…24` | **`P0 / OPEN`** (7/7) |
| Composite Evidence Schema | `REVIEW ACCEPTED / NOT FROZEN` |
| Trust Anchor Contract v0.1 | `REVIEW ACCEPTED / NOT FROZEN` |
| Key Authorization Contract v0.1 | `REVIEW ACCEPTED / NOT FROZEN` |
| ResearchState / Experiment Selection / Research Orchestrator v1.0 | `FROZEN / UNCHANGED` |
| External trust anchors / independent witnesses | `NOT VERIFIED` |
| Trusted admission | **`DENIED`** |
| Trusted implementation | **`NO-GO`** |
| Autonomous execution | **`NO-GO`** |
| Production changes, cryptographic runs, executed conformance | **`NONE`** |
| Proposed Phase 3Y | `NOT AUTHORIZED` |

**Suggested PO acceptance language:** “Phase 3X is accepted as a byte-profile and detached-proof-format **design review**. No protocol schema is frozen, no keys or external proof providers are authorized, no 3M P0 is closed, BW-G2 remains a candidate and `trusted_admission=DENIED`. Any future machine protocol registration, cryptographic test execution, trusted integration or autonomous execution requires a separate explicit PO GO.”
