# CAUSAL 2.0 — Phase 3AE — Independent Human Reference Approval Dossier

**Status: AWAITING EXTERNAL HUMAN REVIEW / NOT APPROVED**. This document is a review package and does **not** constitute a human signature, an attestation, or PO ratification.

## Exact review boundary

- 47 provisional case requirements: 44 byte-form fixtures, 3 synthetic graph-assertion fixtures. The 40 sealed 3AD byte cases are byte-identical. No trusted external evidence enters this corpus.
- 15 `LOCAL_BYTES_MATCH` are **local syntactic/cryptographic** test values only; 3 `GRAPH_MATCH_SYNTHETIC` assert a local dependency graph without external approval.
- Machine comparisons: Python candidate/reference derivation; independent JS byte computation; separately written read-only Python audit; independently evaluated Python and JavaScript graph edges. The crypto libraries may share OpenSSL, therefore independent crypto backend is **unproven**.
- No human reviewer has been contacted, registered or assigned. **0 decisions have been made.** Do not mark any bytes `APPROVED` before external evidence actually exists.

## Independent human workflow (requires real reviewer)

1. PO designates a qualified reviewer **independent from artifact authorship and reference producer**; record verified identity, organization, role, access to source specification, and conflicts. An AI generating this dossier cannot act as that reviewer.
2. Reviewer independently checks the pin of 3X, 3Z, 3AA, 3AB and the exact case-specific `fixture_sha256` and `reference_sha256` in `HUMAN_REVIEW_QUEUE.json`. Verify source fixture semantics, not only hash equality.
3. For each positive BYTE case independently compute canonical payload, byte-length, domain-separated frame, SHA256(frame) and synthetic Ed25519 validity. For each negative case verify the **first** rejection stage and absence of forbidden outputs. A mismatch or ambiguity => **REJECT / ESCALATE**, never auto-update sealed references.
4. For graph cases independently reconstruct each referenced parent subject from raw fixtures, recompute domain-separated body identity and compare the child link. Verify exactly 1, 2, 3 edges for D-01, D-02, D-03, respectively. Do not infer authorization or source provenance from graph equality.
5. Where Python/Node might share an OpenSSL backend, use an independently sourced crypto implementation or document `CRYPTO_BACKEND_INDEPENDENCE_UNVERIFIED` with a narrow approval scope. This is **not** a trusted root/key approval.
6. Any claimed approval must be a **detached** record referring to the exact fixture and reference SHA256, with reviewer identity, independence evidence, method, timestamp, decision and separately verifiable signature/custody proof. PO acceptance of a technical phase is not a substitute for independent human approval.
7. A separate PO decision reviews the independent records and any unresolved disagreements. An unsigned `HUMAN_APPROVAL_RECORD_TEMPLATE.json` is not evidence; local PASS is not approval. A failed or missing reviewer decision leaves `NOT_APPROVED`.

## Mandatory rejection / abstention

- Unknown reviewer, no independence evidence, absent case hash pins, reused case ID, provisional fixture overwritten, inconsistent oracle calculations, mismatched algorithm/version, no signed detached record, mixed source epochs, missing evidence, no PO ratification, or any attempt to label synthetics as authorized => **NO APPROVAL**.
- 3Z-OPEN-01 (ASCII valid inputs cannot discriminate character vs byte lengths) remains **OPEN**. Full corpus 102, external carriers, witness proofs, trusted time, protected floor and independent roots all remain unverified / P0-BLOCKED.
- `trusted_admission=DENIED`; `trusted_implementation=NO-GO`; `autonomous_execution=NO-GO`; never invoke RS→ES→ORC.

## Pending handoff

An independent reviewer can use `HUMAN_REVIEW_QUEUE.json` and the empty template, but the present package supplies **no** fabricated human attestations, reviewer names, signatures or approvals. Future actual detached approvals must be stored outside this sealed provisional corpus until explicitly reconciled via PO change control.
