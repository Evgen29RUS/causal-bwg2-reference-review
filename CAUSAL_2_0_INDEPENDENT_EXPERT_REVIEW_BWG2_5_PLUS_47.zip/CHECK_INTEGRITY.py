#!/usr/bin/env python3
"""Verify transport integrity of this reviewer package. NOT a provenance/security attestation."""
from pathlib import Path
import hashlib,sys
root=Path(__file__).resolve().parent
lines=(root/'MANIFEST_SHA256.txt').read_text(encoding='utf-8').splitlines()
errors=[]; count=0
for line in lines:
 if not line.strip() or line.startswith('#'):continue
 parts=line.split('  ',1)
 if len(parts)!=2:errors.append('BAD_MANIFEST_ENTRY');continue
 expected,rel=parts
 p=(root/rel).resolve()
 if not p.is_relative_to(root.resolve()) or not p.is_file():errors.append(f'MISSING/OUTSIDE: {rel}');continue
 actual=hashlib.sha256(p.read_bytes()).hexdigest()
 if actual!=expected:errors.append(f'HASH_MISMATCH: {rel}')
 count+=1
present={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and p.name!='MANIFEST_SHA256.txt'}
listed={line.split('  ',1)[1] for line in lines if line.strip() and not line.startswith('#') and '  ' in line}
if present!=listed:errors.append(f'INVENTORY_MISMATCH missing={sorted(listed-present)} extra={sorted(present-listed)}')
print(f'REVIEW PACKAGE SHA256: {"PASS" if not errors else "FAIL"} ({count} files checked)')
if errors:
 print('\n'.join(errors));sys.exit(1)
