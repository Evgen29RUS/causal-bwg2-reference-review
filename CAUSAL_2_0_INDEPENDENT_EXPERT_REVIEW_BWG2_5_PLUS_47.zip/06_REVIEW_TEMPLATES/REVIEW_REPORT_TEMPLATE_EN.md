# Independent review report — TEMPLATE ONLY / NOT SIGNED

Reviewer name and affiliation: ___
Review capacity: personal / institutional (specify authorization if institutional): ___
Date/time UTC: ___
Independence / conflict of interest disclosure: ___
Input fixture SHA-256 per reviewed case: ___
Provisional reference SHA-256 per reviewed case: ___
Independent method, languages and crypto backends: ___
Independent canonical payload bytes / frame / SHA256 / signature verification / first negative rejection stage: ___
Per-case verdict (MATCH / DIFF / INCONCLUSIVE): ___
Discrepancies with exact first differing byte: ___
Scope limits and excluded cases: ___
Signed detached review record or signature/custody evidence: ___

No automatic trusted approval, schema freeze or release to RS/ES/ORC.
